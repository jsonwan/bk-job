#### 2025-02-28 *Version:3.7.0.2*

##### Fixes

1. Fix the issue of high CPU usage caused by Jar Class upload in certain scenarios.

###### Compatibility

| Java Agent | AgentCollector    | Platform | Notes                                                                                                |
|------------|-------------------|----------|------------------------------------------------------------------------------------------------------|
| 3.7.0.2    | 3.6.7.0+          | 3.9.0.3+ | Supports ASPM                                                                                        |
| 3.7.0.2    | 3.6.6.4+          | 3.7.1+   | Supports Thread Pool V2 protocol and DNS performance data collection                                 | 
| 3.7.0.2    | 3.6.6.1+          | 3.6.7+   | Supports cross-application tracking whitelist/blacklist, memory dump, and diagnostics                | 
| 3.7.0.2    | 3.6.5.1+          | 3.6.5+   | Compatible with SkyWalking protocol, supports Collector high availability                            | 
| 3.7.0.2    | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol                                                             | 
| 3.7.0.2    | 3.6.4+            | 3.6.2+   | Supports microseconds and designated business system functions, does not support Full Stack Snapshot |
| 3.7.0.2    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 changed the data protocol, requiring platform version 3.6.2 or higher         |
| 3.7.0.2    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                                                                      |



#### 2025-01-22 *Version:3.7.0.1*

##### Fixes

1. Fixed the issue that when the agent was started, the console would print some agent logs


###### Compatibility

| Java Agent | AgentCollector    | Platform | Notes                                                                                                |
|------------|-------------------|----------|------------------------------------------------------------------------------------------------------|
| 3.7.0.1    | 3.6.7.0+          | 3.9.0.3+ | Supports ASPM                                                                                        |
| 3.7.0.1    | 3.6.6.4+          | 3.7.1+   | Supports Thread Pool V2 protocol and DNS performance data collection                                 | 
| 3.7.0.1    | 3.6.6.1+          | 3.6.7+   | Supports cross-application tracking whitelist/blacklist, memory dump, and diagnostics                | 
| 3.7.0.1    | 3.6.5.1+          | 3.6.5+   | Compatible with SkyWalking protocol, supports Collector high availability                            | 
| 3.7.0.1    | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol                                                             | 
| 3.7.0.1    | 3.6.4+            | 3.6.2+   | Supports microseconds and designated business system functions, does not support Full Stack Snapshot |
| 3.7.0.1    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 changed the data protocol, requiring platform version 3.6.2 or higher         |
| 3.7.0.1    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                                                                      |


#### 2024-11-27 *Version:3.7.0*

##### Added

1. Support for ASPM
   - Disabled by default, ASPM can be enabled by modifying the following configuration in tingyun.properties (a restart is required for the changes to take effect).
   ```
    aspm.plugin_enabled=true
    ```
   And enable it on the platform under "APM -> Configuration -> Application Settings -> Application Security ->" by selecting "Advanced Threat Perception".
###### Compatibility

| Java Agent | AgentCollector    | Platform | Notes                                                                                                |
|------------|-------------------|----------|------------------------------------------------------------------------------------------------------|
| 3.7.0      | 3.6.7.0+          | 3.9.0.3+ | Supports ASPM                                                                                        |
| 3.7.0      | 3.6.6.4+          | 3.7.1+   | Supports Thread Pool V2 protocol and DNS performance data collection                                 | 
| 3.7.0      | 3.6.6.1+          | 3.6.7+   | Supports cross-application tracking whitelist/blacklist, memory dump, and diagnostics                | 
| 3.7.0      | 3.6.5.1+          | 3.6.5+   | Compatible with SkyWalking protocol, supports Collector high availability                            | 
| 3.7.0      | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol                                                             | 
| 3.7.0      | 3.6.4+            | 3.6.2+   | Supports microseconds and designated business system functions, does not support Full Stack Snapshot |
| 3.7.0      | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 changed the data protocol, requiring platform version 3.6.2 or higher         |
| 3.7.0      | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                                                                      |

#### 2024-10-31 *Version:3.6.9*

##### Added
1. Support for JDBC query row count monitoring.
2. Support for JDK versions 19, 20, 21 and 22.

##### Improvements
1. Support reporting the cause of the Agent circuit breaker event.
2. Optimized reconnection strategy for Agent when the collector cannot connect.
3. Support for monitoring the idle count of BoneCP, DBCP, HikariCP, Tomcat JDBC, TongWeb DBCP, and BES database connection pools.
4. Support for numeric business system names.

##### Fixes
1. Fixed incorrect status code issue when collecting from Tomcat and TongWeb containers under certain circumstances.
2. Fixed circular class dependency issue during startup in JDK 17 and 18, causing application startup failure.
3. Fixed issue where thread pools were not collected in Jetty 9.1.0 and above.
4. Fixed inaccurate data collection for the active count in the Redisson database connection pool.

###### Compatibility
| Java Agent | AgentCollector    | Platform | Notes                                                                            |
|------------|-------------------|----------|----------------------------------------------------------------------------------|
| 3.6.9    | 3.6.6.4+          | 3.7.1+   | Supports Thread Pool V2 protocol and DNS performance data collection             | 
| 3.6.9    | 3.6.6.1+          | 3.6.7+   | Supports cross-application tracking whitelist/blacklist, memory dump, and diagnostics | 
| 3.6.9    | 3.6.5.1+          | 3.6.5+   | Compatible with SkyWalking protocol, supports Collector high availability         | 
| 3.6.9    | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol                                         | 
| 3.6.9    | 3.6.4+            | 3.6.2+   | Supports microseconds and designated business system functions, does not support Full Stack Snapshot |
| 3.6.9    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 changed the data protocol, requiring platform version 3.6.2 or higher |
| 3.6.9    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                   |

#### 2024-06-07 *Version:3.6.8.3*

##### Fixes
1. Fixed an issue where thread profiling at the transaction level was not generating data.
2. Fixed a problem where, under high concurrency with OkHttp, a single remote call was incorrectly recorded as two remote calls, with an exception being captured during the first remote call.

###### Compatibility
| Java Agent | AgentCollector    | Platform | Notes                                                                            |
|------------|-------------------|----------|----------------------------------------------------------------------------------|
| 3.6.8.3    | 3.6.6.4+          | 3.7.1+   | Supports Thread Pool V2 protocol and DNS performance data collection             | 
| 3.6.8.3    | 3.6.6.1+          | 3.6.7+   | Supports cross-application tracking whitelist/blacklist, memory dump, and diagnostics | 
| 3.6.8.3    | 3.6.5.1+          | 3.6.5+   | Compatible with SkyWalking protocol, supports Collector high availability         | 
| 3.6.8.3    | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol                                         | 
| 3.6.8.3    | 3.6.4+            | 3.6.2+   | Supports microseconds and designated business system functions, does not support Full Stack Snapshot |
| 3.6.8.3    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 changed the data protocol, requiring platform version 3.6.2 or higher |
| 3.6.8.3    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                   |

#### 2024-05-10 *Version:3.6.8.2*

##### Fixes
1. Fixed the issue where host applications on Linux were recognized as microservices. Note: Microservice recognition is not supported when running independently in Containerd containers.
2. Fixed the issue where newly added plugins were not effective at runtime.

##### Improvements
1. Added support for p6spy database JDBC URL parsing.
2. Added support for memory information collection in Containerd/CRI-O container environments.

###### Compatibility
| Java Agent | AgentCollector    | Platform       | Remarks                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.8.2    | 3.6.6.4+          | 3.7.1+   | Supports thread pool V2 protocol and DNS performance data collection                             |
| 3.6.8.2    | 3.6.6.1+          | 3.6.7+   | Supports Cross-Application Trace whitelist/blacklist, Memory Dump and Memory diagnosis |
| 3.6.8.2    | 3.6.5.1+          | 3.6.5+   | Compatible with SkyWalking protocol, supports Collector high availability                   |
| 3.6.8.2    | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol |
| 3.6.8.2    | 3.6.4+            | 3.6.2+   | Supports microseconds and specified business system functionality, does not support Full Stack Snapshot        |
| 3.6.8.2    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires a platform version of 3.6.2 or above |
| 3.6.8.2    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2024-04-18 *Version:3.6.8.1*

##### Fixes
1. Fixed the issue where obtaining PID caused JVM to call DNS resolution.
2. Fixed the issue where memory leaks occurred due to the inability to release registration information during frequent creation and destruction of thread pools and connection pools.

##### Improvements
1. Added support for blocking class information collection based on Classloader.
    - You can modify the following configuration in tingyun.properties to block it:
    ```
    jar_collector.classloader_exclude=com.xxxx,com.xxxx.xxx
    ```
###### Compatibility
| Java Agent | AgentCollector    | Platform | Remarks                                                      |
| ---------- | ----------------- | -------- | :----------------------------------------------------------- |
| 3.6.8.1    | 3.6.6.4+          | 3.7.1+   | Supports thread pool V2 protocol, DNS performance data collection |
| 3.6.8.1    | 3.6.6.1+          | 3.6.7+   | Supports Cross-Application Trace whitelist/blacklist, Memory Dump and Memory diagnosis |
| 3.6.8.1    | 3.6.5.1+          | 3.6.5+   | Compatible with SkyWalking protocol, supports high availability of Collector |
| 3.6.8.1    | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol                     |
| 3.6.8.1    | 3.6.4+            | 3.6.2+   | Supports microsecond and specified business system functionality, does not support Full Stack Snapshot |
| 3.6.8.1    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires platform version 3.6.2 or above |
| 3.6.8.1    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                              |


#### 2024-03-28 *Version:3.6.8*

##### Added
1. Supports configuring data items and user traces using OGNL expressions (Note: OGNL expressions have different levels of performance impact on applications, please fully validate before using in production)
    - You can select "Method parameter(s)" as the data source in "APM->Settings->System Settings/Application Settings->Data Item->Add Data Source for Data Item"
    - You can select "Method parameter(s)" as the data source in "APM->Settings->System Settings/Application Settings->User Tracing->Add Data Source"
    - In the Getter Chain of the above configurations, fill in the OGNL expression ([OGNL User Guide](https://commons.apache.org/dormant/commons-ognl/language-guide.html)), the format is as follows:
    ```
    ognl#<表达式>
      
    Example：ognl#getHeader("User-Agent")
    ```
2. Support HTTP response header rewriting X-Tingyun-Trace
   * This feature is disabled by default and can be enabled by modifying the following configuration in tingyun.properties:
    ```
    action_tracer.response_trace_info.enabled=true
    ```
* X-Tingyun-Trace Format:
    ```
    span_id=<SPAN_ID>,trace_id=<TRACE_ID>
    ```
3. Support for adjusting the owner permissions of the agent directory to OwnerOnly. This feature only supports single-user use of the agent and is disabled by default. To enable it, add the following configuration to tingyun.properties:
    ```
    owner_only=true
    ```
4. Support Tomcat thread pool, compatible with 8.5.70 ~ 8.5.99, 9.0.52 ~ 9.0.87
5. Support Jedis, compatible with redis.clients:jedis (4.0.0 ~ 5.1.1)
6. Support BES connection pool, compatible with 9.5.2
7. Support RESTEasy, compatible with org.jboss.resteasy:resteasy-jaxrs (2.2.0.GA ~ 3.15.6.Final)
8. Support MQTTv3, compatible with org.eclipse.paho:org.eclipse.paho.client.mqttv3 (1.0.2 ~ 1.2.5)
9. Support Apache Pulsar, compatible with org.apache.pulsar:pulsar-client (2.7.0 ~ 2.7.5)
10. Support Logback Logstash, compatible with net.logstash.logback:logstash-logback-encoder (4.0 ~ 7.4)
11. Support Jakarta Servlet, compatible with jakarta.servlet:jakarta.servlet-api (5.0.0-M1 ~ 6.1.0-M2)
12. Support OkHttp connection pool, compatible with com.squareup.okhttp3:okhttp (3.5.0 ~ 3.13.1)

##### Fixes
1. Fixed the issue of unlimited cross-application headers causing header overflow. The default limit for header size is 4096. Headers exceeding the limit will be discarded. You can adjust the following configuration in tingyun.properties to make changes:
    ```
    transaction_tracer.header_max_length=4096
    ```
2. Fixed the issue of Header overflow caused by unlimited CallList in cross-application headers. The default limit for CallList size is set to 512 (approximately 19 topology nodes). After exceeding the limit, no more topology nodes will be added. You can adjust the configuration by modifying the following settings in tingyun.properties:
    ```
    transaction_tracer.header_calllist_max_length=512
    ```
3. Fixed the issue of unable to extract ContainerID under CRI-O containers.
4. Fixed the issue where the Agent log size was not limited after setting the number of log files to 1.
5. Fixed the issue of misaligned Span data under Lettuce synchronous calls.
6. Fixed the issue where application error occurred when using Rest protocol for B's invocation in the Dubbo two-level invocation scenario A->B->C without installing Agent on B and C.
   - The solution to this issue is to add the following configuration to the Agent configuration file tingyun.properties of application A to be compatible with the Rest protocol:
    ```
    dubbo.tracing_base64.enabled=true
    ```
7. Fixed the issue of an extra character in the payload data collection under WebLogic.
8. Fixed the issue of not being able to collect errors in Apache Dubbo.
9. Fixed the issue of incomplete topology when using Rest protocol with SOFARPC.
10. Fixed the issue of signature verification failure after Log4j encoding.

##### Improvements
1. Optimized the agent to reduce initial memory usage and startup time.
2. Optimized user tracing to support browser front-end user trace information.

###### Compatibility
| Java Agent | AgentCollector    | Platform       | Remarks                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.8      | 3.6.6.4+          | 3.7.1+   | Supports thread pool V2 protocol and DNS performance data collection                             |
| 3.6.8      | 3.6.6.1+          | 3.6.7+   | Supports Cross-Application Trace whitelist/blacklist, Memory Dump and Memory diagnosis |
| 3.6.8      | 3.6.5.1+          | 3.6.5+   | Compatible with SkyWalking protocol, supports collector high availability                   |
| 3.6.8      | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol |
| 3.6.8      | 3.6.4+            | 3.6.2+   | Supports microsecond and specified business system functionality, does not support Full Stack Snapshot        |
| 3.6.8      | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 changed the data protocol, requires platform version 3.6.2 or above |
| 3.6.8      | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2023-12-05 *Version:3.6.7.2*

##### Fixes
1. Fixed the issue of NoClassDefFoundError when accessing the application after Resin (4.0.0 ~ 4.0.8) starts.
2. Fixed the issue of multiple RootSpans appearing on a single Trace in asynchronous scenarios.
3. Fixed the issue of not being able to collect Containerid in certain Containerd containers.
4. Fixed the issue of incomplete cross-application topology collection when Dubbo calls more than 2 layers.
5. Fixed the issue of not being able to collect performance data in Dubbo (2.7.5).
6. Fixed the issue of generating background tasks when the number of Spans in a Trace exceeds the limit in Spring Async plugin.

##### Improvements
1. Optimized JarClass reporting data to enhance stability and reduce unnecessary dynamic proxy classes.
2. Optimized custom encoding to support encoding classes without CodeSource.
3. Optimized the maximum number of SQL parameters limit. If exceeded, "TY: over <maximum number>" will be added to the end of the parameters. If adjustment is needed, you can add the following configuration in tingyun.properties:
    ```
    sql_parameter_max_size=64
    ```
4. Optimized Resin container adaptation and improved support for Cross-Application Trace (support for TxData return after application abort)

###### Compatibility
| Java Agent | AgentCollector    | Platform       | Remarks                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.7.2    | 3.6.6.4+          | 3.7.1+   | Supports thread pool V2 protocol, DNS performance data collection                               |
| 3.6.7.2    | 3.6.6.1+          | 3.6.7+   | Supports Cross-Application Trace whitelist/blacklist, Memory Dump and Memory diagnosis |
| 3.6.7.2    | 3.6.5.1+          | 3.6.5+   | Compatible with Skywalking protocol, supports Collector high availability                   |
| 3.6.7.2    | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol |
| 3.6.7.2    | 3.6.4+            | 3.6.2+   | Supports microsecond and specified business system functionality, does not support Full Stack Snapshot        |
| 3.6.7.2    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 changed the data protocol and requires platform version 3.6.2 or above |
| 3.6.7.2    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2023-11-10 *Version:3.6.7.1*

##### Fixes
1. Fixed the issue where Action objects were not released in a timely manner when executing blocking CompletableFuture, GuavaFuture, and ReactorSubscribe.
2. Fixed the issue where Containerid could not be collected in some Containerd environments.
3. Fixed the issue of continuous heap memory growth caused by excessive class loading within 5 minutes.
4. Fixed the issue where WebClient data collection could cause memory overflow.
5. Fixed the issue of potential memory leaks when running Servlet 3.0 applications on Glassfish.

##### Improvements
1. Optimized BES and TongWeb container adaptation and improved support for Cross-Application Trace.
2. Adjusted Reactor Netty adaptation range to adapt to io.projectreactor.netty:reactor-netty (0.8.0.RELEASE ~ 1.1.12).
3. Optimized ClassLoader adaptation logic, added maximum adaptation limit, and no longer adapted ClassLoader beyond the limit. You can modify the following configuration in tingyun.properties.
    ```
     class_transformer.max_validated_classloaders=256
    ```
4. Optimized Logback log traceability adaptation, supporting multiple log file outputs.
5. Changed the naming rules of JSP pages to a more understandable URI naming rule.

###### Compatibility
| Java Agent | AgentCollector    | Platform | Remarks                                                      |
| ---------- | ----------------- | -------- | ------------------------------------------------------------ |
| 3.6.7.1    | 3.6.6.4+          | 3.7.1+   | Supports thread pool V2 protocol and DNS performance data collection. |
| 3.6.7.1    | 3.6.6.1+          | 3.6.7+   | Supports Cross-Application Trace whitelist/blacklist, Memory Dump and Memory diagnosis. |
| 3.6.7.1    | 3.6.5.1+          | 3.6.5+   | Compatible with Skywalking protocol, supports Collector high availability. |
| 3.6.7.1    | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol.                    |
| 3.6.7.1    | 3.6.4+            | 3.6.2+   | Supports microsecond and specified business system functionality, does not support Full Stack Snapshot. |
| 3.6.7.1    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires platform version 3.6.2 or above. |
| 3.6.7.1    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                              |


#### 2023-08-31 *Version:3.6.7*

##### Added
1. Supports thread pool V2 data protocol, adds initialization call stack and thread pool queue usage information.
2. Supports DNS performance data collection.
3. Supports ServiceComb, compatible with org.apache.servicecomb:java-chassis-core (2.1.5 ~ 2.8.6).
4. Supports Play, compatible with com.typesafe.play:play (2.8.3 ~ 2.8.19).
5. Supports Guava google-futures, compatible with com.google.guava:guava (19.0).
6. Supports HBase, compatible with org.apache.hbase:hbase-client (1.1.1 ~ 1.7.2).
7. Supports Apusic, compatible with AAS-V9.0.
8. Supports Netty, compatible with io.netty:netty-all (4.0.20.Final ~ 4.0.56.Final).
9. Supports Oracle ojdbc8, compatible with com.oracle.database.jdbc:ojdbc8 (23.2.0.0).
10. Supports RabbitMQ, compatible with com.rabbitmq:amqp-client (2.7.0 ~ 5.18.0).
11. Supports Spring RabbitMQ, compatible with org.springframework.amqp:spring-rabbit (1.5.2.RELEASE ~ 2.4.14).

##### Fixes
1. Fixed the issue where ContainerID cannot be collected under cgroup v2.
2. Fixed the issue where events were missing when the data item and user trace configuration were the same class and method.
3. Fixed the issue where obtaining a large number of thread statuses caused the JVM to have a long Safepoint time.
   * By default, when the number of application threads exceeds 10000, the agent does not collect thread status data. You can modify the following configuration in tingyun.properties:
   ```
    thread_sample.safe_count=10000
   ```
4. Fixed the issue of not being able to obtain the number of threads and class load/unload count under SpringBoot.
5. Fixed the problem of inconsistency between the total number of thread states and the total number of threads.
6. Fixed the issue of custom embedding affecting transaction types.
7. Fixed the issue of spikes in GC and Safepoint data after enabling the Agent for a long time of disabling it.
8. Fixed the issue of incorrect transaction naming for MQ consumer transactions after disabling automatic transaction naming.

##### Improvements
1. Added support for identifying database Clob, Blob, and NClob data types.
2. Added support for Axis2 asynchronous mode.
3. Optimized the Kafka plugin to support version verification of Kafka producer messages.
4. Optimized the MQ plugin so that no transaction is created on the consumer side when monitoring is disabled.
5. Optimized the Spring-rabbitmq plugin to support performance data collection for MQ in custom listener scenarios.
6. Adjusted the category of traces without transactions to VirtualTrace.
7. Optimized the logic for ending segments to improve the accuracy of performance data for asynchronous components.
8. Kafka Cross-Application Trace monitoring is disabled by default. For specific issues, please refer to (https://wukongdoc.tingyun.com/apm/deploy/Java/troubleshooting.html).
   * After confirming that there are no risks in the application usage scenario, you can enable it by adding the following configuration to the tingyun.properties file.
       ```
         mq.kafka_tracing.enabled=true
       ```
   
   - If the platform version used is 3.7.1+, you can check the "Enable Kafka Trace Monitoring" option in "APM->Settings->Application Settings->Common".
9. Optimize the logic of asynchronous thread correlation.
10. Optimize the performance of HttpAsyncClient plugin.
11. Optimize the RabbitMQ plugin to support MQ performance data collection using basicGet method.
12. Optimize the problem of the automatic object statistics function in memory analysis not being triggered under G1 GC.
13. Optimize the event description information of memory dump in exceptional cases.

###### Compatibility
| Java Agent | AgentCollector    | Platform       | Remarks                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.7      | 3.6.6.4+          | 3.7.1+   | Supports new version of thread pool V2 protocol, DNS performance data collection                           |
| 3.6.7      | 3.6.6.1+          | 3.6.7+   | Supports Cross-Application Trace whitelist/blacklist, Memory Dump and Memory diagnosis. |
| 3.6.7      | 3.6.5.1+          | 3.6.5+   | Compatible with Skywalking protocol, supports Collector high availability                   |
| 3.6.7      | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol. |
| 3.6.7      | 3.6.4+            | 3.6.2+   | Supports microseconds and specified business system functions, does not support Full Stack Snapshot        |
| 3.6.7      | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires the use of platform versions 3.6.2 and above |
| 3.6.7      | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0||


#### 2023-07-20 *Version:3.6.6.1*

##### Fixes
1. Fixed the issue of slow off-heap memory release due to not closing Deflater
2. Fixed the issue where the agent could not reconnect immediately after session expiration
3. Fixed the issue of null pointer in agent metrics aggregation caused by conflict with other agents during agent startup
4. Fixed the issue where the new asynchronous mode did not restrict leaf nodes
5. Fixed the issue where the agent still called getCmds after switching from a higher version Collector to a lower version Collector, resulting in a 404 error
6. Limited the maximum number of collected exceptions to avoid memory overflow caused by excessive exception stack collection (default limit is 128)
7. Fixed the issue where the agent did not report thread state statistics, causing the new application analysis thread count chart in the report to be unable to display
8. Fixed the issue where spaces were still output when Log Tracing was turned off
9. Fixed the issue of inaccurate deadlock thread count collection
10. Fixed the issue of duplicate TraceId and SpanId output in log tracing function under asynchronous mode of log component
11. Fixed the issue of startup failure due to failure to obtain file lock under NFS file system
12. Fixed the issue of Jackson and FastJSON serialization ServletRequest error caused by agent
13. Fixed the issue of inaccurate Safepoint data collection

##### Improvements
1. Support for collecting containerId of Containerd containers
2. Optimized the naming logic of BasicErrorController, adjusted to URI-based naming
3. Automatic object snapshot statistics default to disable object snapshot collection of Parallel OldGC, can be configured and enabled in the platform "APM->Settings->System Settings/Application Settings->Diagnostic Tools"

###### Compatibility
| Java Agent | AgentCollector    | Platform | Notes                                              |
|------------|-------------------|----------|:--------------------------------------------------|
| 3.6.6.1    | 3.6.6.1+          | 3.6.7+   | Supports Cross-Application Trace whitelist/blacklist, Memory Dump and Memory diagnosis | 
| 3.6.6.1    | 3.6.5.1+          | 3.6.5+   | Compatible with Skywalking protocol, supports Collector high availability | 
| 3.6.6.1    | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol           | 
| 3.6.6.1    | 3.6.4+            | 3.6.2+   | Supports microsecond, specified Business System function, does not support Full Stack Snapshot | 
| 3.6.6.1    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 changed the data protocol, requires platform version 3.6.2 or above |
| 3.6.6.1    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                  

#### 2023-05-15 *Version:3.6.6*

##### Added
1. Added support for memory diagnosis of slow memory leaks, which is disabled by default. To enable it, go to "APM -> Settings -> System Settings/Application Settings -> Memory diagnosis -> Memory Analysis" on the platform (This feature may trigger JVM STW. Please enable and use it according to the actual situation).
   * Automatic Object statistics: After an Old GC occurs in the application, instances are automatically selected for memory object snapshot statistics.
   * Automatic Sequential analysis: When the data collection duration reaches 3 hours, the platform automatically analyzes classes with a growing trend in the number of objects and pushes them to application analysis as events.
   * After enabling Memory Analysis, you can also manually create object statistics on the platform under "APM -> Diagnostic Tools".
     - By default, the triggered object statistics will not trigger Full GC. If you need object statistics after Full GC, please select "Trigger Full GC first, then collect object snapshots".
2. Added support for Memory Dump operations on processes, which are disabled by default. To enable it, go to "Global Settings -> Memory Dump" on the platform (This feature may trigger JVM STW. Please use it according to the actual situation).
   * After enabling it, you can create memory dumps on the platform under "APM -> Diagnostic Tools". The memory dump files are stored locally on the server by default and can be dumped to a dump server by selecting it.
3. Added support for black and white lists for Cross-Application Trace. You can configure it under "APM -> Settings -> System Settings/Application Settings -> Transaction" on the platform.
   * If the platform does not support configuration, you can make the following configurations in the agent (In the black and white list configuration, the whitelist has higher priority than the blacklist).
     - Cross-application Tracing black and white list function switch: Enable the configuration to use this function. The specific configuration is as follows:
        ```
        # Cross-application Tracing blacklist and whitelist feature, disabled by default
        # When set to true, the cross-application tracing blacklist and whitelist configurations take effect
        # default: false
        action_tracer.external.enabled=false
        ```
     - Cross-application Trace blacklist configuration. External call requests matched by this configuration will not write Tingyun Header. The specific configuration is as follows:
        ```
        # It can be configured in 3 segments:
        # <PROTOCOL>://, the protocol of the external request, can be configured according to the PROTOCOL reported by the agent, e.g., http://
        # <IP>:<PORT>, the target address of the external request, you can also fill in <IP> or :<PORT> separately. <IP> supports regex matching, starting with ^ and ending with $ indicating regex matching. For example: 192.168.10.10:8080,127.0.0.1,^host-\d+$,:8080
        # /<PATH>, the path of the external request, matched by startWith, example: /query
        action_tracer.external.excludes=<PROTOCOL>://<IP>:<PORT>/<PATH>,<PROTOCOL>://<IP>:<PORT>/<PATH>,...
        ```
     - Cross-application tracing whitelist configuration, only external invocation requests that match this configuration will write Tingyun Header. The specific configuration is as follows:
        ```
        # Note: The whitelist for Cross-application Trace has a higher priority than the blacklist for Cross-application Trace. Once the whitelist is configured, the blacklist will no longer be effective.
        # It can be configured in 3 segments:
        # <PROTOCOL>://, the protocol of the external request, can be configured according to the PROTOCOL reported by the agent, example: http://
        # <IP>:<PORT>, the target address of the external request, you can also fill in <IP> or :<PORT> separately. <IP> supports regex matching, starting with ^ and ending with $ indicating regex matching. For example: 192.168.10.10:8080,127.0.0.1,^host-\d+$,:8080
        # /<PATH>, the path of the external request, matched by startWith, example: /query
        action_tracer.external.includes=<PROTOCOL>://<IP>:<PORT>/<PATH>,<PROTOCOL>://<IP>:<PORT>/<PATH>,...
        ```
4. Agent Fuses supports process CPU usage, default configuration:
   * Agent sampling triggered when CPU usage reaches 80%
   * Agent circuit breaker triggered when CPU usage reaches 90%
5. Supports database connection pool, compatible with com.oracle.database.jdbc:ucp (21.1.0.0 ~ 21.9.0.0)
6. Supports database connection pool, compatible with org.apache.tomcat:tomcat-jdbc (7.0.19 ~ 10.1.8)
7. Supports Redis connection pool, compatible with org.redisson:redisson (3.11.1 ~ 3.16.0)
8. Supports Redis connection pool, compatible with redis.clients:jedis (3.6.0 ~ 3.9.0)
9. Supports Cassandra, compatible with com.datastax.oss:java-driver-core (4.0.0 ~ 4.15.0)
10. Supports Spring @Async annotation, compatible with org.springframework:spring-context (3.1.0 ~ 4.0.9)
11. Supports JettyClient, compatible with org.eclipse.jetty:jetty-client (9.4.35.v20201120 ~ 9.4.50.v20221201)
12. Supports SOFARPC, compatible with com.alipay.sofa:sofa-rpc-all (5.3.1 ~ 5.9.2)

##### Fixes
1. Fixed the issue where Redisson operations could not collect keys.
2. Fixed the deviation in execution time of Trace and root method in synchronous threads.

##### Improvements
1. Supports collecting error stack traces without enabling exception stack trace collection, including error stack traces in logs.
2. Refactored Dubbo plugin to support collecting performance data of asynchronous Callback and resolve the issue of inaccurate collection of external service IP on the Client side.
3. Full stack snapshot supports sending snapshot data in JSON format.
4. Optimized the Agent to avoid triggering DNS queries.
5. Trimmed whitespace when reading numeric configurations in tingyun.properties.
6. To avoid the issue of application block() exceptions caused by Reactor Hook thread switching (see https://github.com/reactor/reactor-core/issues/3450), the Reactor plugin is disabled by default. If there are no scenarios with this exception, you can enable the plugin by modifying the following configuration in tingyun.properties:
    ```
    class_transformer.tingyun-reactor-core-plugin-3.1.0.enabled=true
    class_transformer.tingyun-reactor-core-plugin-3.1.8.enabled=true
    class_transformer.tingyun-reactor-core-plugin-3.4.enabled=true
    ```
7. Optimize Cross-Application Trace configuration, and it will no longer write headers when turned off.

###### Compatibility
| Java Agent | AgentCollector    | Platform | Remarks                                              |
|------------|-------------------|----------|:----------------------------------------------------|
| 3.6.6      | 3.6.6.1+          | 3.6.7+   | Supports Cross-Application Trace whitelist/blacklist, Memory Dump and Memory diagnosis |
| 3.6.6      | 3.6.5.1+          | 3.6.5+   | Compatible with Skywalking protocol, supports Collector high availability |
| 3.6.6      | 3.6.5.1+          | 3.6.2+   | Supports Full Stack Snapshot V2 protocol |
| 3.6.6      | 3.6.4+            | 3.6.2+   | Supports microsecond, specified Business System function, does not support Full Stack Snapshot |
| 3.6.6      | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires a platform version of 3.6.2 or above |
| 3.6.6      | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                     |


#### 2023-03-09 *Version:3.6.5.3*

##### Fixes  
1. Fixed the issue where the full stack snapshot function may stop when the business thread exits quickly.
2. Fixed the issue where there was a residual thread after executing thread profiling.
3. Fixed the issue where the thread profiling function could not be canceled.

###### Compatibility
| Java Agent | AgentCollector | Platform | Remarks                                              |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.5.3     | 3.6.5.1+        | 3.6.5+   | Compatible with Skywalking protocol, supports Collector high availability  | 
| 3.6.5.3     | 3.6.5.1+        | 3.6.2+   | Supports Full Stack Snapshot V2 protocol | 
| 3.6.5.3     | 3.6.4+          | 3.6.2+   | Supports microsecond, specified Business System function, does not support Full Stack Snapshot | 
| 3.6.5.3     | 3.6.1.2+        | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires a platform version of 3.6.2 or above |
| 3.6.5.3     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2023-02-07 *Version:3.6.5.2*

##### Fixes  
1. Fixed the issue of incomplete collection of transaction trace data.
2. Fixed the issue of stack overflow when the nested call depth of transaction trace reaches 20.
3. Fixed the issue of class conversion error after calling the publish and replay methods when using Reactor-core 3.1.0.RELEASE ~ 3.1.7.RELEASE.

###### Compatibility
| Java Agent | AgentCollector | Platform | Remarks                                              |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.5.2     | 3.6.5.1+        | 3.6.5+   | Compatible with Skywalking protocol, supports Collector high availability  | 
| 3.6.5.2     | 3.6.5.1+        | 3.6.2+   | Supports Full Stack Snapshot V2 protocol | 
| 3.6.5.2     | 3.6.4+          | 3.6.2+   | Supports microsecond, specified Business System function, does not support Full Stack Snapshot | 
| 3.6.5.2     | 3.6.1.2+        | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires a platform version of 3.6.2 or above |
| 3.6.5.2     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2023-01-04 *Version:3.6.5.1*

##### Fixes 
1. Fixed the issue of incorrect cross-application callback in Apache Dubbo Callback mode.
2. Fixed the issue of incorrect Starter log file name format when the Agent cannot start due to memory restrictions.

##### Improvements
1. Optimized lock competition for transaction entry under high concurrency to reduce the impact on request response time.

###### Compatibility
| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.5.1    | 3.6.5.1+       | 3.6.5+   | Compatible with Skywalking protocol, supports Collector high availability. |
| 3.6.5.1    | 3.6.5.1+       | 3.6.2+   | Supports Full Stack Snapshot V2 protocol. |
| 3.6.5.1    | 3.6.4+         | 3.6.2+   | Supports microsecond and specified business system functionality, does not support Full Stack Snapshot. |
| 3.6.5.1    | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires using platform version 3.6.2 or above. |
| 3.6.5.1    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ | |

#### 2022-12-08 *Version:3.6.5*

##### Added
1. Supports Collector high availability by automatically connecting to accessible Collectors.
2. Compatible with Skywalking's cross-application topology protocol. This feature requires using platform version 3.6.5 and adding the following configuration in the collector.properties file on the Collector side to enable Skywalking compatibility.
   ```
     tracing.vendor=skywalking
   ```
   
   * Note: After modifying the collector.properties, it is necessary to restart the Collector, and the Agent connecting to the Collector also need to be restarted.
3. Support for ResponseBody data collection. This feature is enabled by default through comprehensive parameter configuration. If you need to enable it, you can configure it in tingyun.properties:
   ```
     action_tracer.capture_full_parameters=true
   ```
   If you need to disable the collection of ResponseBody separately, you can configure it in tingyun.properties:
   
   ```
     action_tracer.capture_response_body_enabled=false
   ```
   
   Note:
   
   * When configuring data items or user tracing, the key for configuration is "ResponseBody".
   * The default maximum request length is 2048, and the maximum collection length can be configured as 10240 characters. If it exceeds this limit, it will be truncated and "{0} more chars" will be added at the end. {0} represents the number of ignored characters. If you need to modify it, you can modify the following configuration in tingyun.properties:
        ```
           max_request_parameter_size=2048
        ```

4. Support for naming database types using aliases. If you need to use them, you can configure them in tingyun.properties.
   ```
    action_tracer.database_alias_filter=Database Alias//hostname:port,ip:port;Database Alias//ip:port,ip:port
   ```
   
   * Configuration Instructions: The default matching method for hostname and IP is startsWith. If regular expression matching is required, it should start with "^". Multiple ip:port under one alias should be separated by ",", and multiple database aliases should be separated by ";".
   * Configuration Example: OpenGauss//192.168.2.213:5432,192.168.2.102;GoldenDB//10.128.2.95,^.*golden_server:3306
      - If the database target address is 192.168.2.213:5432 or the IP is 192.168.2.102, the database type is OpenGauss.
      - If the database IP is 10.128.2.95 or matches the regular expression ^.*golden_server:3306, the database type is GoldenDB.
5. When the agent starts, memory restrictions are added. By default, if the maximum heap memory is less than 400MB, embedded startup will not be performed.
   * This feature is enabled by default. If you want to disable it, you can modify the following configuration in tingyun.properties:
    ```
        agent_start_check.enabled=false
    ```
   
   * If you need to modify the heap memory limit value, you can modify the following configuration in tingyun.properties (unit: MB):
   
       ```
           agent_start_check.min_memory=400
       ```
6. Data items and user traceability support collecting array data.
   * The default maximum collection length for data items is 2048 characters. If you need to change it, you can modify the following configuration in tingyun.properties (restart required for the changes to take effect):

    ```
        data_item.max_length=2048
    ```
   
   * The default maximum collection length for user tracing is 50 characters. If you need to change it, you can modify the following configuration in tingyun.properties (restart required for the changes to take effect):
       ```
           user_info.max_length=50
       ```
7. Supports org.elasticsearch:elasticsearch (7.3.0 ~ 7.17.7)
8. Supports org.elasticsearch.client:elasticsearch-rest-high-level-client (7.5.0 ~ 7.17.7)
9. Supports com.ibm.mq:com.ibm.mq.allclient (9.0.4.0 ~ 9.3.0.1)
10. Supports org.redisson:redisson (3.13.0 ~ 3.17.7)
11. Supports org.springframework.cloud:spring-cloud-circuitbreaker-resilience4j (1.0.0.RELEASE ~ 2.1.5)
12. Supports org.quartz-scheduler:quartz (1.3.4 ~ 1.8.6)
13. Supports io.vertx:vertx-core (3.8.0 ~ 3.8.5)
14. Supports org.apache.kafka:kafka_2.11 (0.10.0.0 ~ 0.10.2.2)
15. Supports com.xuxueli:xxl-job-core (1.9.0 ~ 2.3.1)
16. Supports networkbench tingyun Middleware (9.5.2)
17. Supports Middleware from Zhongchuang (9.1)
18. Supports TongWeb7 Connection Pool
19. Supports Proxool Connection Pool (0.9.1)
20. Supports Undertow (1.0.0.Final ~ 2.2.21.Final)

##### Fixes
1. Fixed the issue of collecting incorrect data when Redisson uses batch commands.
2. Fixed the issue of outputting null in log tracing when there is no transaction.
3. Fixed the issue of Agent reloading and causing high CPU usage when the system time is earlier than the modification time of the plugin under the extensions directory.
4. Fixed the issue of not being able to collect ports under the TongWeb container.
5. Fixed the issue of not being able to collect snapshot data under gRPC.
6. Fixed the issue of not being able to obtain schema in the HttpClient5 plugin.
7. Fixed the compatibility issue between log tracing and Skywalking.
8. Fixed the issue of not being able to write back cross-application headers normally when Resteasy uses Netty as the underlying container.
9. Disabled the Reactor-mysql plugin by default. After configuring the connection pool, the plugin will execute database calls in batches, making it difficult to accurately locate the corresponding Trace.

##### Improvements
1. Optimized full stack snapshots to reduce CPU usage of the Collector.
2. Optimized connection pool data to reduce duplicate registration data.
3. Refactored the OkHttp plugin to reduce CPU usage and improve exception collection.
4. Refactored the AsyncHttpClient to improve exception collection.
5. Refactored the Kafka plugin to support exception collection.
6. Optimized the Reactor-core plugin to reduce memory usage. Enabled by default.
7. Optimized the Lettuce plugin to reduce CPU usage and improve exception collection.
8. Unified debug log output and removed the configuration -Dtingyun.debug=true.
9. Refactored the Dubbo plugin to be compatible with version 3.x.
10. Optimized the Filter plugin to reduce duplicate Tracer creation.
11. Optimized the MQ plugin to stop writing cross-application headers on the production side after disabling monitoring on the consumer side.
12. Optimized Class adapter cache to reduce memory usage.
13. Supports performance data collection for Jdbc executeLargeUpdate.
14. Adjusted the status code of HTTP calls. Status codes below 400 are considered normal requests.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.5      | 3.6.5.1+       | 3.6.5+   | Compatible with Skywalking protocol, supports high availability of the Collector |
| 3.6.5      | 3.6.5.1+       | 3.6.2+   | Supports Full Stack Snapshot V2 protocol |
| 3.6.5      | 3.6.4+         | 3.6.2+   | Supports microseconds and specified business system functionality, does not support Full Stack Snapshot |
| 3.6.5      | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2 changed the data protocol, requires platform version 3.6.2 or above |
| 3.6.5      | 3.5.4.1 ~ 3.6.1.1 |3.5.4.0+||

#### 2022-10-21 *Version:3.6.4.2*

##### Added
1. Support org.apache.kafka:kafka-clients (0.11.0.0 ~ 1.1.1)

##### Fixes
1. Fixed the issue of not collecting SQL in the scenario of using OJDBC driver with PreparedStatement.
2. Fixed the application startup failure issue in Oracle JDK (16 ~ 18) or OpenJDK (16 ~ 18) environment with Netty framework.

##### Improvements
1. Optimized the issue of not collecting SQL in the scenario of using Shentong database with PreparedStatement.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.4.2    | 3.6.4+         | 3.6.2+   | Supports Full Stack Snapshot, microsecond, and specified business system functions. |
| 3.6.4.2    | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires the use of platform version 3.6.2 and above. |
| 3.6.4.2    | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |

#### 2022-09-22 *Version:3.6.4.1*

##### Fixes
1. Fixed the issue of incorrect transaction name when calling Spring @Async annotation under Agent circuit breaker sampling or background task.
2. Fixed the issue of memory not being released when encountering exceptions in non-web requests without transaction entry in trace.
3. Fixed the issue of NullPointerException logs during Agent startup.

##### Improvements
1. Optimized data collection for Reactor (reactor-core plugin is turned off by default) to reduce CPU usage.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.4.1    | 3.6.4+         | 3.6.2+   | Supports Full Stack Snapshot, microsecond, and specified business system functions. |
| 3.6.4.1    | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires the use of platform version 3.6.2 and above. |
| 3.6.4.1    | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |

#### 2022-08-03 *Version:3.6.4*

##### Added
1. Support Mongodb connection pool (3.5.0 ~ 4.2.3).
2. Support c3p0 connection pool (0.9.0-pre5 ~ 0.9.0.4, 0.9.2-pre2-RELEASE ~ 0.9.5).
3. Support Tomcat 5 thread pool.
4. Support com.datastax.cassandra:cassandra-driver-core (2.0.7 ~ 2.0.12.3, 2.1.2 ~ 3.11.2).
5. Support dev.miku:r2dbc-mysql (0.8.1.RELEASE ~ 0.8.2.RELEASE)
6. Support io.lettuce:lettuce-core (6.0.0.RELEASE ~ 6.1.8.RELEASE)
7. Support io.projectreactor:reactor-core (3.1.0.RELEASE ~ 3.4.17)
   * The plugin is disabled by default. If you need to enable it, add the following configuration to tingyun.properties (application restart required):
   * After enabling the plugin, there will be a noticeable increase in CPU usage. Please enable it according to your actual needs.
    ```
        class_transformer.tingyun-reactor-core-plugin-3.1.enabled=true
        class_transformer.tingyun-reactor-core-plugin-3.4.enabled=true
    ```
8. Support redis.clients:jedis (3.6.0 ~ 3.9.0)
9. Support org.jboss.resteasy:resteasy-core (4.4.0.Final ~ 5.0.3.Final)
10. Support io.grpc:grpc-core (1.6.0 ~ 1.18.0, 1.22.0 ~ 1.29.0)
11. Support Apache Log4j (2.13.2 ~ 2.18.0) for asynchronous mode log tracing
12. Support collection of object growth rate and promotion rate for Oracle Hotspot JVM and OpenJDK JVM (unit: MB/s)
13. Support data collection for TongWeb 7 middleware by Dongfangtong


##### Improvements
1. Support for JDK15, JDK16, JDK17, JDK18
2. Support for Request Payload data collection with ContentType as application/text, text/plain in Spring WebMVC
3. Log tracing auto-injection, no need to modify log configuration files, also compatible with previous log configurations
   * Default log output format:
    ```
        [tingyun.app_id:ApplicationID,tingyun.trace_id:TRACEID,tingyun.span_id:SPANID]
    ```
4. Optimize the performance of agent embedding.
5. Optimize the Netty plugin, enable by default.
6. Support configuration of parent class methods for data item or user traceability through Getter chain.
7. Support recognition of OceanBase, OpenGauss, and ClickHouse databases.
8. Optimize the OkHttp plugin to support collecting topology data in case of exceptions and timeouts.

##### Fixes
1. Fix the issue of automatic application naming failure.
2. Fix the issue of failed cross-application correlation when using HTTPS protocol with HttpURLConnection.
3. Fix the issue of Agent not collecting business exceptions after an exception occurs in a SpringBoot application using Tomcat container.
4. Fix the issue of Agent repeatedly initializing, causing application memory overflow.
5. Fix the issue of user traceability or data item configuration not taking effect when configured to collect This object.
6. Fix the issue of user traceability or data item configuration not taking effect when configuring Getter chain as toString.
7. Fix the issue of data not being collected when Redisson uses Object Key.

###### Compatibility
| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.4      | 3.6.4+         | 3.6.2+   | Supports Full Stack Snapshot, microseconds, and specified business system functionality. |
| 3.6.4      | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires the use of platform version 3.6.2 and above. |
| 3.6.4      | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ | |

#### 2022-07-26 *Version:3.6.3.3*

##### Fixes
1. Fix the issue of not collecting database data under JDK9 ~ 14.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.3.3    | 3.6.4+         | 3.6.2+   | Supports Full Stack Snapshot, microseconds, and specified business system functionality. |
| 3.6.3.3    | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires the use of platform version 3.6.2 and above. |
| 3.6.3.3    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ | |

#### 2022-05-18 *Version:3.6.3.2*

##### Fixes
1. Fix the issue of memory overflow caused by collecting a large number of asynchronous call data in a single request.
2. Fix the issue of not collecting 500 error requests under Wildfly.
3. Fix the issue of unable to generate topology data after a 500 error occurs in Tomcat.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.3.2    | 3.6.4+         | 3.6.2+   | Supports Full Stack Snapshot, microseconds, and specified business system functionality. |
| 3.6.3.2    | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires the use of platform version 3.6.2 and above. |
| 3.6.3.2     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |

#### 2022-04-01 *Version:3.6.3.1*

##### Added
1. Support com.squareup.okhttp:okhttp (2.7.0 ~ 2.7.5)
2. Support Spring Async (4.2.0.RELEASE ~ 5.3.17)

##### Improvements
1. Optimize the timeout exception collection for Spring Cloud Gateway
2. Support Containerd container microservice identification

##### Fixes
1. Fix the issue of generating snapshot data when there is no message consumption after enabling Kafka consumption feature
2. Fix the problem of cross-application with OpenFeign plugin
3. Fix the calculation error of exclusive time for transactions without traces and the misclassification of component information
4. Fix the incomplete collection of errors in external service calls with Dubbo
5. Fix the issue of Dubbo service exceptions not being collected as transaction errors
6. Fix the issue of not collecting external service calls when Reactor Netty requests timeout
7. Fix the performance degradation caused by Jar Class information collection

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.3.1     | 3.6.4+         | 3.6.2+   | Supports Full Stack Snapshots, microseconds, and specified business system functionality |
| 3.6.3.1     | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires the use of platform versions 3.6.2 and above |
| 3.6.3.1     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |

#### 2021-12-29 *Version:3.6.3*

##### Added
1. Support Full Stack Snapshots, enabled by default. To adjust, go to "APM->Settings->System Settings->Performance Diagnosis",
   * Supported snapshot modes:
       - Triggered collection mode, determines whether a request is captured based on the configured percentage of slow requests. Default trigger condition: 10% of slow requests within 1 minute (total count > 20)
       - Fixed period collection mode, captures snapshots based on the configured fixed time period. Default trigger condition: capture 10 full stack snapshots within 1 minute
       - Forced collection mode, disabled by default, captures snapshots based on the configured slow threshold. Default trigger condition: request execution time greater than 3 times the slow request threshold
2. Collect data with precision up to microseconds
3. Support data collection for Nantong databases
4. Support memory data collection for OpenJ9
5. Support io.projectreactor.netty:reactor-netty (1.0.0 ~ 1.0.14)
6. Support specifying the business system, with the default business system being "default". To modify, update the following configuration in tingyun.properties:
  ```
    default_business_system=default
  ```
​	or add the following configuration in JVM startup parameters:
   ```
    -Dtingyun.default_business_system=default
   ```
7. Support WebSphere connection pool (7.x)
8. Support collection of Response Code based on HTTP protocol for HttpClient, OkHttp, UrlConnection, Feign, Reactor Netty, etc. RPC frameworks (such as Dubbo) are not supported for now. Data can be viewed in the Call Table of trace details.

##### Improvements
1. When there is no database name in the URL of DM and Shentong databases, use the default name as the database name.
2. Optimize exception handling for Jersey-Client plugin.
3. Optimize Agent performance.

##### Fixes
1. Fix the issue of Agent startup failure when adding configuration items of numeric type in the command line.
2. Fix ConcurrentModificationException error during thread pool collection in concurrent scenarios.
3. Fix the issue of timeout exceptions not being collected by WebClient and timeout without cross-application issues.
4. Fix the issue of transaction naming in WebFlux and Zuul plugins not being aggregated in the backend.
5. Fix the issue of OpenJ9 startup failure.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.3      | 3.6.4+         | 3.6.2+   | Supports Full Stack Snapshot, microseconds, and specified business system functionality. |
| 3.6.3      | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2 has changed the data protocol and requires platform version 3.6.2 and above. |
| 3.6.3      | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |

#### 2021-12-22 *Version:3.6.2.4*

##### Fixes
1. Fix the issue of incomplete performance data sent under high concurrency.
2. Fix the issue of application calling database error in the scenario of using Dangdang's ShardingJdbc for database master-slave or database sharding.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.2.4    | 3.5.4.1+      | 3.5.4.0+ | It is recommended to use AgentCollector 3.6.2.1+ to fix the issue of abnormal display of method call order in asynchronous scenarios. |

#### 2021-12-06 *Version:3.6.2.3*

##### Fixes
1. Fix the issue of application re-embedding caused by dynamically modifying the application name.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.2.3    | 3.5.4.1+      | 3.5.4.0+ | It is recommended to use AgentCollector 3.6.2.1+ to fix the issue of abnormal display of method call order in asynchronous scenarios. |

#### 2021-11-05 *Version:3.6.2.2*
##### Fix
1. Fixed the issue of Json serialization failure in the JFinal framework.

##### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.2.2    | 3.5.4.1+      | 3.5.4.0+ | It is recommended to use AgentCollector 3.6.2.1+ to fix the issue of abnormal display of method invocation order in asynchronous scenarios. |


#### 2021-10-27 *Version:3.6.2.1*

##### Fix
1. Fixed the issue of application error caused by writing user trace collection results that exceed the header length.
* The default limit is 50 characters. To change it, modify the following configuration in tingyun.properties (restart is required for the changes to take effect):
  ```
    user_info.max_length=50
  ```
##### Improvement
1. Optimize the length of data item collection.
* The default limit is 2048 characters. If you need to change it, modify the following configuration in tingyun.properties (restart is required for the changes to take effect):

   ```
    data_item.max_length=2048
   ```
###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.2.1    | 3.5.4.1+      | 3.5.4.0+ | It is recommended to use AgentCollector 3.6.2.1+ to fix the issue of abnormal display of method call order in asynchronous scenarios. |


#### 2021-10-22 *Version:3.6.2*

##### Added
1. Support for org.apache.httpcomponents.client5:httpclient5 (5.0 ~ 5.1)

2. Support for org.apache.httpcomponents:httpasyncclient (4.0 ~ 4.1.4)

3. Support for org.asynchttpclient:async-http-client (2.1.0 ~ 2.12.3)

4. Support for com.squareup.okhttp3:okhttp (3.14.0 ~ 3.14.9)

5. Support for
     - org.mongodb:mongo-java-driver (3.7.0 ~ 3.12.10)
     - org.mongodb:mongodb-driver-sync (3.7.0 ~ 4.3.2)
     - org.mongodb:mongodb-driver-async (3.7.0 ~ 3.12.10)
     
6. Support for org.redisson:redisson (2.3.0 ~ 2.15.2)

7. Support for
     - org.elasticsearch:elasticsearch (6.0.0 ~ 6.8.18)
     
     - org.elasticsearch.client:elasticsearch-rest-high-level-client (6.6.0 ~ 6.8.18)
       * ElasticSearch Query DSL collection is enabled by default. To disable it, you can modify the following configuration in tingyun.properties (restart is required for the changes to take effect):
       ```
         es.capture_operation=false
       ```
       
       * The default length of the collected ElasticSearch Query DSL is 2000 characters. If it exceeds this limit, it will be truncated and supplemented with "[{0} more chars]" at the end, where {0} represents the number of characters that have been truncated. If you need to modify this, you can change the following configuration in tingyun.properties (restart required for the changes to take effect):
       ```
         action_tracer.insert_sql_max_length=2000
       ```
8. Support commons-dbcp:commons-dbcp (1.2 ~ 1.4)
9. Support org.apache.commons:commons-dbcp2 (2.0 ~ 2.9.0)
10. Support com.jolbox:bonecp (0.7.1.RELEASE & 0.8.0.RELEASE)
11. Support org.apache.httpcomponents:httpclient connection pool (4.3 ~ 4.5.13)
12. Support WebSphere connection pool (8.5)
13. Support org.apache.shiro:shiro-core (1.2.0 ~ 1.8.0) for user information collection
    * Disabled by default. To enable, modify the following configuration in tingyun.properties (requires restart to take effect):
    ```
    class_transformer.tingyun-shiro-plugin-1.0.enabled=true
    ```
    * When configuring user tracing and data items, the data source is Servlet session attribute, with the key "TINGYUN_SHIRO_LOGIN_USER".

14. Support Jvm SafePoint data collection.
15. Support off-heap memory (MappedByteBuffer, DirectByteBuffer) data collection.
16. Support transaction naming for Spring Zuul 2.0.0.RELEASE ~ 2.2.9.RELEASE.
17. Support ignoring Spans in traces with exclusive time less than the specified time, only supports Code type. Exceptions, asynchronous, Database, NoSQL, MQ, POOL, External types will not be ignored.
    * Enabled by default. To disable, modify the following configuration in tingyun.properties (requires restart to take effect):
    ```
     action_tracer.reduce.enabled=false
    ```
    * Ignore method calls within the specified time, by default ignore method calls of 0 milliseconds (requires restart to take effect):
    ```
     action_tracer.reduce.span_ignore_duration=0
    ```
18. Support enabling audit mode for specified data interfaces, and support dynamic activation of audit mode.
    * It is disabled by default. To enable it, you can modify the following configuration in tingyun.properties:
    ```
     audit_mode=true
    ```
    * To enable audit mode for specified data interfaces, you can configure one or multiple data interfaces. Multiple data interfaces should be separated by commas. If you need to enable it, you can modify the following configuration in tingyun.properties:
    ```
     audit_mode.interfaces=jvm,trace,jar,getCmd,hotspot,uploadFile,uploadProfile,redirect
    ```
##### Improvements
1. Optimized connection pool to address the issue of slow application access in high-concurrency scenarios.
2. Added MD5 cache for transaction names to improve performance.
3. Added JDBC URL cache to reduce redundant parsing and improve performance.
4. Optimized CompletableFuture plugin to reduce unnecessary method nesting.
5. Optimized log traceability under resource protection or circuit breaking, resolving the issue of identical transaction IDs (optimized to a fixed value: DUMMY_ACTION_GUID).

##### Fixes
1. Fixed the issue of failed CPU usage retrieval for IBM JDK.
2. Fixed the issue of incorrect span ID retrieval for Hystrix asynchronous threads.
3. Fixed the issue of inaccurate performance data for Jedis, Lettuce, and Redisson.
4. Fixed the issue of exception in Jedis getResource method call and class conversion failure.
5. Fixed the issue of inability to upload application JAR files.
6. Fixed the issue of garbled data collection from Web request query parameters.
7. Fixed the issue of failed invocation when user trace contains Chinese characters.
8. Fixed the issue of Netty transactions not being released.
9. Fixed the issue of unable to retrieve port for WebSphere.
10. Fixed the issue of unable to retrieve port for Wildfly.
11. Fixed the issue of multiple cross-application calls captured in a single HttpURLConnection call.
12. Fixed the issue of Agent startup error when SSL is not enabled and the application system lacks SSL libraries.
13. Fixed the issue of bytecode error for Okhttp (3.4.0 ~ 3.4.2).

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.2      | 3.5.4.1+       | 3.5.4.0+ | It is recommended to use AgentCollector 3.6.2.1+ to fix the issue of abnormal method call order in asynchronous scenarios. |

#### 2021-08-27 *Version:3.6.1.7*

##### Fixes
1. Fixed the issue of slow application access in high-concurrency scenarios when using Alibaba Druid connection pool.
2. Fixed the issue of incorrect classification of transaction performance metrics when the number of spans per request exceeds the threshold (default: 3000).
3. Fixed the issue of possible memory overflow when the response body in cross-application requests is too large.
4. Fixed the issue of possible memory overflow when the application client uses WebSocket to call Webflux server.
5. Fixed the issue of failure to collect Weblogic database connection pool information.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.1.7    | 3.5.4.1+       | 3.5.4.0+ |  |

#### 2021-07-28 *Version:3.6.1.6*

##### Fixes
1. Removed Druid connection pool plugin.
###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | :------ |
| 3.6.1.6    | 3.5.4.1+       | 3.5.4.0+ |         |


#### 2021-07-14 *Version:3.6.1.5*

##### Fixes

1. Fixed the issue with data collection for Sybase and Informix databases.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | :------ |
| 3.6.1.5    | 3.5.4.1+       | 3.5.4.0+ |         |

#### 2021-06-18 *Version:3.6.1.4*

##### Fixes

1. Fixed the issue where using the jconn driver to connect to Sybase database caused StackOverflowError, resulting in application access failure.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | :------ |
| 3.6.1.4    | 3.5.4.1+       | 3.5.4.0+ |         |

#### 2021-05-23 *Version:3.6.1.3*

##### Fixes

1. Fixed the issue where when the number of levels of invocation between Apache Dubbo applications is greater than 2, and the called Dubbo service uses the REST protocol to call other Dubbo services, an exception occurs, resulting in business access failure.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | :------ |
| 3.6.1.3    | 3.5.4.1+       | 3.5.4.0+ |         |

#### 2021-05-20 *Version:3.6.1.2*

##### Fixes

1. Fixed the issue where RocketMQ Producer may fail to send messages under high concurrency.
###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.1.2    | 3.5.4.1+       | 3.5.4.0+ |         |

#### 2021-05-11 *Version:3.6.1.1*

##### Fixes

1. Fixed the issue where cross-application related data is inaccurate when the number of layers in Apache Dubbo application calls exceeds 2.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.1.1    | 3.5.4.1+       | 3.5.4.0+ |         |

#### 2021-04-28 *Version:3.6.1*

##### Added

1. Added support for SpringSchedule 3.1.0.RELEASE ~ 5.3.5
2. Added support for Jedis 3.0.0 ~ 3.5.2
3. Added support for JedisPool 3.0.0 ~ 3.5.2 connection pool
4. Added support for Okhttp 4.4.0 ~ 4.9.1
5. Added support for Spring Webflux 5.0.1.RELEASE ~ 5.3.5
6. Added support for Spring WebClient 5.0.1.RELEASE ~ 5.3.5
7. Added support for Dubbo 2.7.0 ~ 2.7.1
8. Added support for Mule 3.6.0 ~ 3.7.0
9. Added topology recognition for Nginx applications
10. Added data collection for Docker 1.11 ~ ce-20 managed by Kubernetes
11. Added data collection for R2DBC-MySQL 0.8.0.RELEASE ~ 0.8.1.RELEASE in background tasks
12. Added data collection for Request Payload in Spring Webmvc 3.2.0.RELEASE ~ 5.3.5

Note:

* Collecting Request Payload consumes more CPU resources, enable with caution.
* When configuring data items and user tracing, use "Payload" as the configuration key.
* Disabled by default. To enable data collection, modify the following configuration in tingyun.properties.
```
   action_tracer.capture_full_parameters=true
```
* The default maximum length of a request is 2048, and the maximum collection length can be configured to be 10240 characters. If it exceeds this limit, it will be truncated and ({0} more chars) will be appended at the end. {0} represents the number of ignored characters. If you need to modify this, you can modify the following configuration in tingyun.properties:
```
   max_request_parameter_size=2048
```
13. Support thread pool data collection (including JDK thread pool and container thread pool)

- The default number of thread pools collected is 200. If you need to modify it, you can modify the following configuration in tingyun.properties:
   ```
     thread_pool.max_size=200
   ```
##### Improvements

1. Optimized browser embedding function to prevent page garbled and white screen issues in certain scenarios.
2. Optimized trace sending method to support batch sending, improving Agent performance.

##### Fixes

1. Fixed the "Unknown" issue in performance metrics for database JDBC.
2. Fixed the issue of failing to retrieve app_name and license_key from environment variables.
3. Fixed the incorrect naming of RocketMQ consumer instances.
4. Fixed the issue of "Unknown" host and port names for components such as HttpClient, OkHttpClient, AsyncHttpClient in certain scenarios.
5. Fixed the issue of semicolon ";" being used as a delimiter in transaction names.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks |
| ---------- | -------------- | -------- | ------- |
| 3.6.1      | 3.5.4.1+       | 3.5.4.0+ |         |

#### 2021-03-23 *Version:3.6.0.1*

##### Fixes

1. Fixed the issue of jdbc batch plugin causing application access failure in certain scenarios.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks                                                      |
| ---------- | -------------- | -------- | ------------------------------------------------------------ |
| 3.6.0.1    | 3.5.4.1+       | 3.5.4.0+ | Supports SQL obfuscation logic being moved to Agent Collector to optimize Agent performance. |

#### 2021-01-25 *Version:3.6.0*

##### Added

1. Added support for Lettuce 5.0.0.RELEASE ~ 5.3.6.RELEASE.

##### Improvements

1. Supported formatting output collection of error logs for Slf4j, Logback, and Log4j.
2. Moved SQL obfuscation logic to Agent Collector.
3. Supported data collection for SocketInputStream.

- SocketInputStream-related plugins are disabled by default. If there are scenarios that require SocketInputStream usage, modify the following configuration in tingyun.properties.
  ```
   class_transformer.tingyun-java.socket-input-stream-plugin.enabled=true
  ```
4. Trace data supports asynchronous sending.

- By default, it is disabled. If you want to enable collection, you can modify the following configuration in tingyun.properties:

  ```
   trace_send.async=true
  ```
- Applicable to scenarios where data loss during sending and data backlog leads to increased memory

5. Trace data sending timeout setting, in seconds

- Default is 1 second. If you need to modify it, you can change the following configuration in tingyun.properties:
  ```
   trace_send.timeout=1
  ```

- Adjusting this value appropriately can avoid data sending failure due to network jitter

6. Trace data supports Gzip compression for sending

- Default is off. If you need to enable it, you can change the following configuration in tingyun.properties:
  ```
   trace_send.gzip=true
  ```

- Applicable to scenarios with high network bandwidth requirements. Enabling Gzip compression can significantly reduce network traffic transmission, thereby reducing bandwidth requirements; however, the trade-off is additional CPU/memory resource consumption
###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks                                                      |
| ---------- | -------------- | -------- | :----------------------------------------------------------- |
| 3.6.0      | 3.5.4.1+       | 3.5.4.0+ | Supports SQL obfuscation logic after Agent Collector to optimize Agent performance |

#### 2020-12-09 *Version:3.5.3*

##### Added

1. Support Dubbox 2.8.0 ~ 2.8.4
2. Support data collection for database connection pool c3p0 (0.9.1 ~ 0.9.1.2)

##### Improvements

1. Support load balancer components (example: Nginx) to maintain Agent and Collector session through cookies
2. Support parsing SQL Server database JDBC URL

##### Fixes

1. Fix the issue of class redefinition caused by Spymemcached plugin
2. Fix the failure to parse Oracle database JDBC URL
3. Disable reporting of dynamically generated class information by Cglib

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks                                                      |
| ---------- | -------------- | -------- | :----------------------------------------------------------- |
| 3.5.3      | 3.5.3+         | 3.5.4.0+ | Supports new version error analysis feature                  |
|            | 3.5.1+         | 3.4.0+   | Ensure synchronization of Agent and platform time            |
|            | 3.4.0+         | 3.4.0+   | Supports collecting Request parameters (excluding POST Body) |

#### 2020-10-31 *Version:3.5.1*

##### Added

1. Support JDK9, JDK10, JDK11, JDK12, JDK13, JDK14

##### Improvements

1. Automatically detect containers without manually blocking part of the container's ClassLoader encoding
2. Adapt to OneAgent, automatically adjust log data directory and instance naming

##### Fixes

1. Fix the issue of incomplete class information upload due to excessive number of loaded classes
2. Fix the issue of Agent exception caused by truncating the configuration user trace string
3. Fixed the issue of unsupported Transaction ID for Browser Agent.
4. Fixed the issue of unable to obtain instance port due to instance name settings.
5. Fixed the issue of CPU consumption when Browser embedding is closed.
6. Fixed the issue of gRPC stream mode not being cross-application.
7. Fixed the issue of AsyncHttpClient not being cross-application.
8. Fixed the issue of thread blocking due to hostname retrieval.
9. Fixed the issue of CompletableFuture plugin unable to release transactions under JDK11.
10. Fixed the issue of incorrect transaction naming when accessing SpringController default pages.
11. Fixed the issue of application access failure caused by exception in obtaining database connection information.
12. Removed support for Spymemcached (which affects the collection of performance data in Spymemcached mode) to avoid application startup failure caused by class loading errors caused by Spymemcached plugins.

###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks                                                      |
| ---------- | -------------- | -------- | ------------------------------------------------------------ |
| 3.5.1      | 3.5.3+         | 3.5.4.0+ | Supports the use of new error analysis features              |
|            | 3.5.1+         | 3.4.0+   | Ensures synchronization of Agent and platform time           |
|            | 3.4.0+         | 3.4.0+   | Supports the collection of Request parameters (excluding POST Body) |

#### 2020-10-20 *Version:3.4.8*

##### Added

1. Collects complete Request parameters (excluding POST Body)

Note:

* The default maximum collection length is 512 characters, and the maximum collection length can be configured to 2048 characters. If you need to change it, you can modify the following configuration in tingyun.properties.
```
  action_tracer.capture_full_parameters_length=512
```
* This feature is disabled by default. To enable data collection, you can modify the following configuration in tingyun.properties:
```
   action_tracer.capture_full_parameters=true
```
##### Improvements

1. Support for new version of Error Analysis
2. Built-in NTP service to ensure synchronization of agent and platform time
3. Optimized performance issues caused by excessive depth of exception stack collected by the agent. The default limit for maximum exception stack depth collection has been changed from 2000 to 100. If you need to change it, you can modify the following configuration in tingyun.properties:
```
    error_collector.max_stack_depth=100 
```
###### Compatibility

| Java Agent | AgentCollector | Platform | Remarks                                                      |
| ---------- | -------------- | -------- | ------------------------------------------------------------ |
| 3.4.8      | 3.5.3+         | 3.5.4.0+ | Supports the use of new error analysis feature               |
|            | 3.5.1+         | 3.4.0+   | Ensures synchronization of Agent and platform time           |
|            | 3.4.0+         | 3.4.0+   | Supports collection of Request parameters (excluding POST Body) |

#### 2020-08-31 *Version:3.4.7*

##### Fixes

1.Fixed the issue where accessing applications caused exceptions when the Oracle JDBC URL was in TNSName format.

###### Compatibility

| AgentCollector | Platform  |
| ------         | ------    | 
| 3.4.0+         | 3.4.0+    |

#### 2020-07-10 *Version:3.4.6*

##### Fixes

1.Removed support for Spring Webflux (affects the collection of performance data for Spring Webflux and Spring Gateway), to avoid issues with Agent causing application unavailability under Spring Webflux 5.1.0.RELEASE ~ 5.1.2.RELEASE, 5.1.7.RELEASE ~ 5.1.8.RELEASE.

###### Compatibility

| AgentCollector | Platform  |
| ------         | ------    | 
| 3.4.0+         | 3.4.0+    |

#### 2020-04-28    *Version:3.4.5*

###### Added

1.Supports transaction-level thread profiling.
2.Supports method parameter-named transactions.
3.Supports Jersey Client 2.0 ~ 2.30.1.
4.Supports Spring Gateway 2.1.4.RELEASE ~ 2.2.2.RELEASE.
5.Supports Spring Webflux 5.1.11.RELEASE ~ 5.2.5.RELEASE.

###### Fixes

1. Fixed the issue where cross-application communication from browser Agent to backend was incorrect under Webflux.
2. Fixed the issue where ReactorNetty topology display was incorrect.
3. Fixed the issue where byte collection was not performed under ActiveMQ and producers could not obtain IP and port.
4. Fixed the issue where URL parameter-named transactions using URL parameters could not be used before calling HttpServletRequest.getParameter.
5. Fixed the issue of not being able to obtain the port under SpringBoot's NettyWebServer.
6. Fixed the issue of the Agent failing to start when placed in the root directory.
7. Fixed the issue of not being able to obtain the response status code under Jetty7.
8. Fixed the issue of Agent startup failure under IBM J9.
9. Fixed the issue of not being able to obtain user identification under WebLogic 10.3.6.
10. Fixed the issue of business method invocation failure under Dubbo's REST protocol.

###### Compatibility

| AgentCollector | Platform |
| ---- | ---- |
| 3.4.0 | 3.4.0 |

#### 2020-03-09    *Version:3.4.0*

###### Added

1. Support OneAgent working mode, see 《OneAgent Deployment & Management Manual》 for details.
2. Support data collection for the following database connection pools:
   * Druid 0.2.4 ~ 1.1.21
   * Hikaricp 2.4.0 ~ 3.4.2
   * c3p0 0.9.5.1 ~ 0.9.5.5
   * WebLogic 10.3.6, 12.1, 12.2
3. Support data collection for Jedis 2.6.3 ~ 2.10.2 connection pool.
4. Support Alibaba RocketMQ 3.2.6, 3.4.6.
5. Support Apache RocketMQ 4.4.0 ~ 4.6.1.
6. Support Kafka 2.0.x ~ 2.4.x.
7. Support Spring Kafka 2.2.0.RELEASE ~ 2.4.4.RELEASE.
8. Support Redisson 2.9.x ~ 2.15.x, 3.5.x ~ 3.12.x.
9. Support RabbitMQ 5.0.x ~ 5.8.x.
10. Support Spring RabbitMQ 2.2.0.RELEASE ~ 2.2.5.RELEASE.

###### Improvements

1. To ensure optimal memory control and transaction collection, the resource protection function automatically adjusts the transaction collection frequency in sampling mode. (Note: The transaction sampling rate on the report is no longer effective)
2. When the number of transaction traces exceeds 3000, optimize the continued memory occupation.
3. Refactor Alibaba Dubbo to adapt to 2.0.10+ (RMI protocol 2.6.0+).
4. Refactor Apache Dubbo to adapt to 2.7.2+ (not support RMI protocol).

###### Fixes

1. Fixed the issue of unable to browser embed the first page output without header under WebLogic.
2. Fixed the issue of Agent not collecting class information generated by the defineClass method.
3. Fixed the issue of reporting "Log method not found" when starting certain Tomcat instances.
4. Fixed the issue of not obtaining the correct return value when using Dubbo 2.7.2 and above versions in the application.
5. Fixed the cross-application issue in WebSphere 8.
6. Fixed the issue of transaction not being released in Jetty 6.

#### 2020-02-04    *Version:3.3.3*
###### Added

1. Added support for performance monitoring of JDBC batch execution of SQL.

###### Improvements

1. The tracing function now supports asynchronous mode for Logback (1.2+) and Log4j (1.2+) logging frameworks.
2. Added the ability to automatically generate multiple log directories when multiple application processes share a single agent. This feature is disabled by default. To enable it, add the following configuration to tingyun.properties:
```
    agent_log_auto_dir.enabled=true
```
Note:

* By default, the agent supports up to 100 application processes sharing one Agent. If you need to modify this, you can add the following configuration in the settings file:
 ```
     agent_log_auto_dir.size=100
 ```
* This feature does not support automatic upgrade and requires manual update of the agent directory and restart to take effect.

###### Fixes

1. Fixed the issue where the cookie written by the agent in the browser embedding code was decoded by the page application, causing page exceptions.
2. Fixed the issue where temporary data continued to increase after the number of database calls exceeded the transaction depth limit in a single request.
3. Fixed the issue where the agent could not upload some classes information in SpringBoot applications after startup.
4. Fixed the issue where Dubbo cross-application call relationships could not be displayed in the business system topology.

#### 2019-11-04    *Version:3.3.1*

###### Added

1. Added support for Spring Gateway 2.0.0.RELEASE ~ 2.1.3.RELEASE.
2. Added support for Spring Webflux 5.0.4.RELEASE ~ 5.1.10.RELEASE (excluding 5.1.2.RELEASE, 5.1.7.RELEASE, 5.1.8.RELEASE).
3. Added support for Okhttp 4.0.0 ~ 4.2.2.

###### Improvements

1. For the issue of the agent failing to start under WebSphere (IBM JDK), added the option to send data using the Json protocol (requires the use of Collector version 3.3.1). To enable Json protocol data, add the following configuration to tingyun.properties:
```
    sendType=json
```
###### Fixes

1. Fixed the issue where the Agent collected excessive stack traces and caused high memory usage. The maximum stack depth for collection is now limited to 2000 by default.
2. Fixed the issue where the Agent could not collect SQL statements when the application used the built-in database connection pool of Weblogic.
3. Fixed the issue where the Agent did not report Class information when the application was deployed using a War package.
4. Fixed the issue where Cglib classes were displayed when searching for custom embedded code in reports. Cglib class information is now blocked.
5. Fixed the issue where asynchronous transactions might not be associated if the child thread was not immediately executed after instantiation.
6. Fixed the issue where the 3.3.0 Agent could not collect transactions on WebSphere 8.5.
7. Fixed the issue where transactions could not be released in Jetty6 container with the 3.3.0 Agent.
8. Fixed the issue where the Agent did not handle cross-application issues in the ReplyTo scenario of ActiveMQ.
9. Fixed the inconsistency between the location of HttpClient3.1 exception collection and external calls.

#### 2019-09-20    *Version:3.3.0*

###### Added

1. Added support for Apache version of Dubbo 2.7.2 and 2.7.3.
2. Added support for Servlet 3.0 asynchronous mode in the following containers:
   * Tomcat 6.0.0 ~ 9.0.20
   * Jetty 8.0.0.M3 ~ 9.4.20.v20190813 (excluding 9.1.1v20140108, 9.3.0.x, 9.4.0.x)
   * Resin 4.0.09 ~ 4.0.62 (excluding 4.0.14, 4.0.15)
   * Wildfly 8.0.0.Final ~ 8.2.1.Final
   * Jboss 7.0.2.Final ~ 7.1.1.Final
   * Weblogic 12.2.1, 12.2.1.1, 12.2.1.2
   * Glassfish 3.1.1 ~ 4.1.2

###### Improvements

1. Optimized the usage of Metaspace by the Agent.
2. Initialized instance ports, prioritizing container ports. If there is no container, the application server port will be used.
3. To prevent potential transaction release delays or lack of transactions when adapting the Netty plugin to non-container scenarios, the Netty plugin is now disabled by default. If Netty is used as a container, the plugin can be enabled by adding the following configuration to tingyun.properties:


```
    class_transformer.tingyun-netty-plugin-3.2.5.enabled=true
    class_transformer.tingyun-netty-plugin-3.4.enabled=true
    class_transformer.tingyun-netty-plugin-3.8.enabled=true
    class_transformer.tingyun-netty-plugin-4.0.0.enabled=true
    class_transformer.tingyun-netty-plugin-4.0.8.enabled=true
```
###### Fixes

1. Fixed the issue of logging Agent connection problems to application logs.
2. Fixed the issue of Wildfly and Jboss not starting due to LogManager not being configured under Oracle Jdk.
3. Fixed the issue of Jdbc plugin reporting plugin tool class not found in some applications.
4. Fixed the issue of Agent Api class not found in Jboss7.
5. Fixed the issue of transaction naming as URI/ when custom embedding is configured for background threads and used as transaction entry.
6. Fixed the intermittent issue of Jmx data reporting by the Agent.
7. Fixed the issue of no cross-application when HttpClient is used concurrently.

###### Known Issues

1. Agent version 3.1.0 ~ 3.3.0 do not currently support WebSphere (IBM JDK), it is expected to be fixed in the next version. If you are currently using WebSphere (IBM JDK), it is recommended to use Agent version 3.0.1, corresponding Agent Collector version 3.0.0, and platform version 3.0.0.
2. If a child thread is instantiated but not executed immediately, there may be an issue with asynchronous transaction association, which is expected to be fixed in the next version.

#### 2019-07-01    *Version:3.2.1*

###### Added

1. Added support for capturing the number of affected rows in executeUpdate of JDBC drivers.
2. Added support for "Ignore Exception Classes" setting in report configuration, which allows ignoring specified exceptions or errors thrown in transactions.

###### Improvements

1. Modified the format of uploading JDBC database addresses. Currently using IP address format instead of host name format.

###### Fixes

1. Fixed the issue of application deadlock caused by the database plugin in certain situations.
2. Fixed the issue of memory leak caused by the Agent when resource protection or Agent is not connected to the Collector.
3. Fixed the issue of incorrect application naming in a single application container with multiple deployments.

###### Known Bugs

1. Enabling Browser automatic embedding in applications may cause white screen on Tomcat and Weblogic containers when Chunk outputting pages.

#### 2019-05-20    *Version:3.2.0*

###### Added

1. Added support for custom embedding of classes and methods in report configuration, and upload corresponding embedding status.
2. Added new ways to retrieve user information, all retrieval methods support getter chain:
   - Method parameters
   - Method return values
   - Current object
   - Http Response Header
   - Web request path
3. Support for multiple ways of retrieving user information simultaneously, and determine the final user information based on the priority of retrieval methods.
4. Add data item data acquisition method, all acquisition methods support getter chain
    * Web request query string
    * Http request header
    * Http Post parameter
    * Http response header
    * Servlet session attribute
    * Web request URL
    * Web request path
5. Support Feign plugin, support version **9.5.0** to **10.2.3**
6. Support Spring cloud openfeign plugin, support version **2.0.0.RELEASE** to **2.1.1.RELEASE**

###### Improvements

1. Optimize the Agent connection method to reduce the opening of network strategies

###### Fixes

1. Fix the issue that browser Agent cannot obtain TINGYUN_DATA when ContextType retrieval fails

#### 2019-04-17    *Version:3.1.2*

###### Fixes

1. Fix the issue of probabilistic class initialization failure under resource protection

#### 2019-04-12    *Version:3.1.1*

###### Fixes

1. Fix the issue of probabilistic loss of request parameters in Servlet 3.0 asynchronous scenarios

#### 2019-03-27    *Version:3.1.0*

###### Added

1. Support CXF 3.1
2. Support Glassfish Jersey 2.9
3. Support Sun Jersey 1.19

###### Improvements

1. Optimize communication protocol to significantly improve TPS and reduce CPU usage
2. Optimize data item functionality to support interface calls
3. Optimize custom embedding functionality to automatically erase unused embeddings

###### Fixes

1. Fix the issue of inaccurate sampling rate under resource protection
2. Fix the issue of partial performance indicators lost by the Agent
3. Fix the issue of incorrect transaction naming after using Dubbo with Spring dynamic proxy
4. Fix the issue of NullPointerException when collecting Spring Boot jar packages.

#### 2019-02-18    *Version:3.0.1*

###### Added

1. Added data processing support for user identification collected in user tracing.

###### Improvements

1. Support transaction naming using Spring annotations in interfaces.
2. Enhanced compatibility of Browser embedding.

###### Fixes

1. Fixed the issue of not being able to obtain the Glassfish version number.
2. Fixed the issue of incorrect time statistics for asynchronous requests.
3. Fixed the issue of incorrect Resin port retrieval.
4. Fixed the issue of unable to collect transactions for Weblogic EJB calls.
5. Fixed the issue of not being able to obtain the Wildfly8 version number.
