#### 2025-02-28 *Version:3.7.0.2*

##### 修复

1. 修复在某些场景下，Jar Class上传导致CPU占用过高的问题

###### 兼容

| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.7.0.2    | 3.6.7.0+          | 3.9.0.3+ | 支持ASPM                                          | 
| 3.7.0.2    | 3.6.6.4+          | 3.7.1+   | 支持线程池V2协议、DNS性能数据采集                             | 
| 3.7.0.2    | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.7.0.2    | 3.6.5.1+          | 3.6.5+   | 兼容SkyWalking协议，支持Collector高可用                   | 
| 3.7.0.2    | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.7.0.2    | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.7.0.2    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.7.0.2    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |

#### 2025-01-22 *Version:3.7.0.1*

##### 修复

1. 修复探针启动时，控制台会打印部分探针日志的问题


###### 兼容

| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.7.0.1    | 3.6.7.0+          | 3.9.0.3+ | 支持ASPM                                          | 
| 3.7.0.1    | 3.6.6.4+          | 3.7.1+   | 支持线程池V2协议、DNS性能数据采集                             | 
| 3.7.0.1    | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.7.0.1    | 3.6.5.1+          | 3.6.5+   | 兼容SkyWalking协议，支持Collector高可用                   | 
| 3.7.0.1    | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.7.0.1    | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.7.0.1    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.7.0.1    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |

#### 2024-11-27 *Version:3.7.0*

##### 新增

1. 支持ASPM
   - 默认关闭，可以在tingyun.properties中修改以下配置开启ASPM(需要重启才能生效)
   ```
    aspm.plugin_enabled=true
    ```
   并且在平台 "应用与微服务->配置->应用设置->应用安全" 勾选 "深度威胁感知" 
   


###### 兼容

| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.7.0      | 3.6.7.0+          | 3.9.0.3+ | 支持ASPM                                          | 
| 3.7.0      | 3.6.6.4+          | 3.7.1+   | 支持线程池V2协议、DNS性能数据采集                             | 
| 3.7.0      | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.7.0      | 3.6.5.1+          | 3.6.5+   | 兼容SkyWalking协议，支持Collector高可用                   | 
| 3.7.0      | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.7.0      | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.7.0      | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.7.0      | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |

#### 2024-10-31 *Version:3.6.9*

##### 新增

1. 支持JDBC查询返回行数监控
2. 支持JDK19,20,21,22

##### 优化

1. 支持探针熔断事件上报时携带导致探针熔断的原因
2. 优化探针在collector无法连接的情况下的重连策略
3. 支持采集BoneCP,DBCP,HikariCP,Tomcat JDBC,TongWeb DBCP,宝兰德数据库连接池空闲数
4. 业务系统名称支持数字

##### 修复

1. 修复Tomcat,TongWeb容器在某些情况下采集到的状态码不正确的问题
2. 修复JDK17,18环境下启动时类循环依赖错误导致应用启动失败的问题
3. 修复Jetty9.1.0以上版本无法采集到线程池的问题
4. 修复Redisson数据库连接池采集used数据不准确的问题

###### 兼容

| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.9      | 3.6.6.4+          | 3.7.1+   | 支持线程池V2协议、DNS性能数据采集                             | 
| 3.6.9      | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.6.9      | 3.6.5.1+          | 3.6.5+   | 兼容SkyWalking协议，支持Collector高可用                   | 
| 3.6.9      | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.6.9      | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.6.9      | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.9      | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |


#### 2024-06-07 *Version:3.6.8.3*

##### 修复
1. 修复事务级别线程剖析无数据的问题
2. 修复OkHttp高并发下，一次远程调用被错误地采集为两次远程调用，并在首次远程调用中捕获到异常的问题

###### 兼容
| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.8.3    | 3.6.6.4+          | 3.7.1+   | 支持线程池V2协议、DNS性能数据采集                             | 
| 3.6.8.3    | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.6.8.3    | 3.6.5.1+          | 3.6.5+   | 兼容SkyWalking协议，支持Collector高可用                   | 
| 3.6.8.3    | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.6.8.3    | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.6.8.3    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.8.3    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |


#### 2024-05-10 *Version:3.6.8.2*

##### 修复
1. 修复Linux下主机应用被识别为微服务的问题  注： 不支持Containerd容器独立运行情况下的微服务识别
2. 修复运行时新增插件无法生效的问题

##### 改进
1. 支持p6spy数据库JDBC URL解析
2. 支持Containerd/CRI-O容器环境的内存信息采集

###### 兼容
| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.8.2    | 3.6.6.4+          | 3.7.1+   | 支持线程池V2协议、DNS性能数据采集                             | 
| 3.6.8.2    | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.6.8.2    | 3.6.5.1+          | 3.6.5+   | 兼容SkyWalking协议，支持Collector高可用                   | 
| 3.6.8.2    | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.6.8.2    | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.6.8.2    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.8.2    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2024-04-18 *Version:3.6.8.1*

##### 修复
1. 修复获取PID导致JVM调用DNS解析问题
2. 修复线程池、连接池频繁创建销毁的过程中，不能释放注册信息导致内存泄露的问题

##### 优化
1. 支持根据Classloader屏蔽Class信息采集
    - 可以在tingyun.properties中修改以下配置进行屏蔽：
    ```
    jar_collector.classloader_exclude=com.xxxx,com.xxxx.xxx
    ```

###### 兼容
| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.8.1    | 3.6.6.4+          | 3.7.1+   | 支持线程池V2协议、DNS性能数据采集                             | 
| 3.6.8.1    | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.6.8.1    | 3.6.5.1+          | 3.6.5+   | 兼容SkyWalking协议，支持Collector高可用                   | 
| 3.6.8.1    | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.6.8.1    | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.6.8.1    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.8.1    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2024-03-28 *Version:3.6.8*

##### 新增
1. 支持以OGNL表达式的方式配置数据项和用户溯源(注: OGNL表达式对应用有不同程度的性能影响，请在生产使用前充分验证)
    - 可以在平台 "应用与微服务->配置->系统设置/应用设置->数据项->添加数据项获取来源"中选择Method parameter(s) 配置数据项
    - 可以在平台 "应用与微服务->配置->系统设置/应用设置->用户溯源->添加数据源"中选择Method parameter(s) 配置用户溯源
    - 以上配置的Getter Chain中填写OGNL表达式([OGNL使用手册](https://commons.apache.org/dormant/commons-ognl/language-guide.html))，格式如下：
    ```
    ognl#<表达式>
   
    例：ognl#getHeader("User-Agent")
    ```
2. 支持HTTP响应头回写X-Tingyun-Trace
    * 功能默认关闭，可以在tingyun.properties中修改以下配置进行启用：
    ```
    action_tracer.response_trace_info.enabled=true
    ```
    * X-Tingyun-Trace 格式：
    ```
    span_id=<SPAN_ID>,trace_id=<TRACE_ID>
    ```
3. 支持探针目录拥有者权限调整为OwnerOnly，此功能仅支持单用户使用探针，默认关闭，如需启用可在tingyun.properties中增加以下配置：
    ```
    owner_only=true
    ```
4. 支持Tomcat线程池，适配 8.5.70 ~ 8.5.99，9.0.52 ~ 9.0.87
5. 支持Jedis，适配redis.clients:jedis (4.0.0 ~ 5.1.1)
6. 支持宝兰德连接池，适配 9.5.2
7. 支持RESTEasy，适配org.jboss.resteasy:resteasy-jaxrs (2.2.0.GA ~ 3.15.6.Final)
8. 支持MQTTv3，适配org.eclipse.paho:org.eclipse.paho.client.mqttv3 (1.0.2 ~ 1.2.5)
9. 支持Apache Pulsar，适配org.apache.pulsar:pulsar-client (2.7.0 ~ 2.7.5)
10. 支持Logback Logstash，适配net.logstash.logback:logstash-logback-encoder (4.0 ~ 7.4)
11. 支持Jakarta Servlet，适配jakarta.servlet:jakarta.servlet-api (5.0.0-M1 ~ 6.1.0-M2)
12. 支持OkHttp连接池，适配com.squareup.okhttp3:okhttp (3.5.0 ~ 3.13.1)

##### 修复
1. 修复跨应用Header无限制导致Header溢出的问题，默认限制Header大小为4096，超出限制后将丢弃Header，可以在tingyun.properties中修改以下配置进行调整：
    ```
    transaction_tracer.header_max_length=4096
    ```
2. 修复跨应用Header中CallList无限制导致Header溢出的问题，默认限制CallList大小为512(约为19个拓扑节点)，超出限制后将不再增加拓扑节点，可以在tingyun.properties中修改以下配置进行调整：
    ```
    transaction_tracer.header_calllist_max_length=512
    ```
3. 修复CRI-O容器下无法提取ContainerID的问题
4. 修复日志文件数设置为1后，探针日志大小不受限制的问题
5. 修复Lettuce同步调用下，Span数据错位的问题
6. 修复Dubbo两级调用场景A->B->C，在B、C不装探针的情况下，B使用Rest协议调用时应用报错的问题
    - 该问题的修复方案是在A应用的探针配置文件tingyun.properties中增加以下配置，以兼容Rest协议：
    ```
    dubbo.tracing_base64.enabled=true
    ```
7. 修复WebLogic下Payload采集数据多一个字符的问题
8. 修复Apache Dubbo采集不到错误的问题
9. 修复SOFARPC在使用Rest协议的情况下拓扑不全的问题
10. 修复Log4j嵌码后出现签名校验失败的问题

##### 优化
1. 优化探针，降低初始内存占用，减少启动时间
2. 优化用户溯源，支持Browser前端用户溯源信息

###### 兼容
| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.8      | 3.6.6.4+          | 3.7.1+   | 支持线程池V2协议、DNS性能数据采集                             | 
| 3.6.8      | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.6.8      | 3.6.5.1+          | 3.6.5+   | 兼容SkyWalking协议，支持Collector高可用                   | 
| 3.6.8      | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.6.8      | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.6.8      | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.8      | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2023-12-05 *Version:3.6.7.2*

##### 修复
1. 修复Resin(4.0.0 ~ 4.0.8)启动后，访问应用报NoClassDefFoundError的问题
2. 修复异步场景下一个Trace上出现多个RootSpan的问题
3. 修复在个别Containerd容器中采集不到Containerid的问题
4. 修复Dubbo调用多于2层时，跨应用拓扑采集不全的问题
5. 修复Dubbo(2.7.5)采集不到性能数据的问题
6. 修复Spring Async插件在一个Trace的Span数超限后产生后台任务的问题

##### 优化
1. 优化JarClass上报数据，增强稳定性及减少不必要的动态代理类
2. 优化自定义嵌码，支持对没有CodeSource的类进行嵌码
3. 优化SQL参数最大个数限制，超出限制后会在末端参数增加"TY: over <最大个数>"。如需调整，可以在tingyun.properties中增加以下配置：
    ```
    sql_parameter_max_size=64
    ```
4. 优化Resin容器适配，完善跨应用追踪支持（支持应用abort后的TxData返回）

###### 兼容
| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.7.2    | 3.6.6.4+          | 3.7.1+   | 支持线程池V2协议、DNS性能数据采集                               | 
| 3.6.7.2    | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.6.7.2    | 3.6.5.1+          | 3.6.5+   | 兼容Skywalking协议，支持Collector高可用                   | 
| 3.6.7.2    | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.6.7.2    | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.6.7.2    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.7.2    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2023-11-10 *Version:3.6.7.1*

##### 修复
1. 修复在执行阻塞的情况下，CompletableFuture、GuavaFuture、ReactorSubscribe不能及时释放Action对象的问题
2. 修复在个别Containerd中采集不到Containerid的问题
3. 修复5分钟内类加载过多导致堆内存持续增长的问题
4. 修复WebClient数据采集可能引发内存溢出的问题
5. 修复在Glassfish上运行Servlet3.0应用时可能出现内存泄漏的问题

##### 优化
1. 优化宝兰德、TongWeb容器适配，完善跨应用追踪支持
2. 调整Reactor Netty适配范围，适配io.projectreactor.netty:reactor-netty (0.8.0.RELEASE ~ 1.1.12)
3. 优化ClassLoader适配逻辑，增加最大适配限制，超过限制后将不再适配ClassLoader，可以在tingyun.properties中修改以下配置
    ```
     class_transformer.max_validated_classloaders=256
    ```
4. 优化Logback日志溯源适配，支持多日志文件输出
5. 将JSP页面的命名规则改为更易理解的URI命名规则

###### 兼容
| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.7.1    | 3.6.6.4+          | 3.7.1+   | 支持线程池V2协议、DNS性能数据采集                               | 
| 3.6.7.1    | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.6.7.1    | 3.6.5.1+          | 3.6.5+   | 兼容Skywalking协议，支持Collector高可用                   | 
| 3.6.7.1    | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.6.7.1    | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.6.7.1    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.7.1    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2023-08-31 *Version:3.6.7*

##### 新增
1. 支持线程池V2数据协议，增加了初始化调用栈及线程池队列使用情况
2. 支持DNS性能数据采集
3. 支持ServiceComb，适配 org.apache.servicecomb:java-chassis-core (2.1.5 ~ 2.8.6)
4. 支持Play，适配 com.typesafe.play:play (2.8.3 ~ 2.8.19)
5. 支持Guava google-futures，适配 com.google.guava:guava (19.0)
6. 支持HBase，适配 org.apache.hbase:hbase-client (1.1.1 ~ 1.7.2)
7. 支持Apusic，适配 AAS-V9.0
8. 支持Netty，适配 io.netty:netty-all (4.0.20.Final ~ 4.0.56.Final)
9. 支持Oracle ojdbc8，适配 com.oracle.database.jdbc:ojdbc8 (23.2.0.0)
10. 支持RabbitMQ，适配 com.rabbitmq:amqp-client (2.7.0 ~ 5.18.0)
11. 支持Spring RabbitMQ，适配 org.springframework.amqp:spring-rabbit (1.5.2.RELEASE ~ 2.4.14)

##### 修复
1. 修复在cgroup v2下采集不到ContainerID的问题
2. 修复数据项和用户溯源配置为同一个类及方法时缺少事件的问题
3. 修复获取大量线程状态导致JVM长时间Safepoint的问题
   * 默认情况下，当应用线程数大于10000时，探针不做线程状态数据采集，可以在tingyun.properties中修改以下配置：
   ```
    thread_sample.safe_count=10000
   ```
4. 修复SpringBoot下获取不到线程数和Class加载卸载数
5. 修复线程状态总数和总线程数不一致的问题
6. 修复自定义嵌码影响事务类型的问题
7. 修复在长时间禁用探针的情况下，启用探针后的GC和Safepoint的数据出现尖刺的问题
8. 修复关闭事务自动命名后，MQ消费端事务命名不正确的问题

##### 优化
1. 支持数据库Clob，Blob，NClob数据类型标识
2. 支持Axis2异步模式
3. 优化Kafka插件，支持kafka生产者消息版本校验
4. 优化MQ插件，在MQ消费端监控关闭下，消费端不再创建事务
5. 优化Spring-rabbitmq插件，支持在自定义Listener情况下的MQ性能数据采集
6. 调整无事务Trace的Category为VirtualTrace
7. 优化Segment结束逻辑，提升异步组件性能数据的准确性
8. 默认禁用Kafka跨应用追踪监控，具体问题详见（https://wukongdoc.tingyun.com/apm/deploy/Java/troubleshooting.html）
   * 确认应用使用场景中没有存在风险后，可以通过以下方式进行启用：
     - 在tingyun.properties配置文件中增加以下配置进行启用：
       ```
         mq.kafka_tracing.enabled=true
       ```
     - 如使用的平台版本为3.7.1+，可以在 "应用与微服务->配置->应用设置->常规选项" 中勾选启用Kafka追踪监控
9. 优化异步线程关联逻辑
10. 优化HttpAsyncClient插件性能
11. 优化RabbitMQ插件，支持使用basicGet方式时的MQ性能数据采集
12. 优化内存分析-自动对象统计功能在G1 GC下不易触发的问题
13. 优化内存Dump在异常情况下的事件描述信息

###### 兼容
| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.7      | 3.6.6.4+          | 3.7.1+   | 支持新版线程池V2协议、DNS性能数据采集                           | 
| 3.6.7      | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断                         | 
| 3.6.7      | 3.6.5.1+          | 3.6.5+   | 兼容Skywalking协议，支持Collector高可用                   | 
| 3.6.7      | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.6.7      | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.6.7      | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.7      | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2023-07-20 *Version:3.6.6.1*

##### 修复
1. 修复没有关闭Deflater导致堆外内存释放缓慢的问题
2. 修复探针会话失效后不能立即重连的问题
3. 修复探针启动时和其他探针冲突导致探针指标汇总出现空指针的问题
4. 修复新版的异步模式没有限制住叶子节点的问题
5. 修复探针从高版本Collector切回低版本Collector后仍调用getCmds导致404的问题
6. 限制最大采集异常数，避免异常堆栈采集过多导致内存溢出的问题（默认限制128个）
7. 修复探针未上报线程状态统计信息导致报表新版应用分析线程数图表无法展示的问题 
8. 修复关闭日志溯源的情况下仍输出空格的问题
9. 修复死锁线程数采集不准确的问题
10. 修复在日志组件的异步模式下日志溯源功能输出TraceId、SpanId重复的问题
11. 修复NFS文件系统下获取文件锁失败导致启动失败的问题
12. 修复探针导致Jackson和FastJSON序列化ServletRequest报错的问题
13. 修复Safepoint数据采集不准确的问题

##### 优化
1. 支持采集Containerd容器的containerId
2. 优化BasicErrorController命名逻辑，调整为以URI方式命名
3. 自动对象快照统计默认禁用Parallel OldGC的对象快照采集，可在平台 "应用与微服务->配置->系统设置/应用设置->诊断工具" 中进行配置启用

###### 兼容
| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.6.1    | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断            | 
| 3.6.6.1    | 3.6.5.1+          | 3.6.5+   | 兼容Skywalking协议，支持Collector高可用                   | 
| 3.6.6.1    | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.6.6.1    | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.6.6.1    | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.6.1    | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2023-05-15 *Version:3.6.6*

##### 新增
1. 支持针对慢速内存泄露的内存诊断，默认关闭，如需开启可在平台 "应用与微服务->配置->系统设置/应用设置->诊断工具->内存分析" 中开启（该功能会触发JVM STW，请根据实际情况开启使用）
   * 自动对象统计功能，会在应用发生Old GC后，自动挑选实例进行内存对象快照统计
   * 自动环比分析，当数据采集时长达到3个小时后，平台自动分析对象数有增长趋势的类，并以事件的形式推送到应用分析上
   * 启用内存分析后，也可手动在平台 "应用与微服务->诊断工具" 中创建对象统计
     - 默认触发的对象统计不会触发Full GC，如需Full GC后的对象统计，请勾选 "先触发Full GC，然后再采集对象快照"
2. 支持对进程进行内存Dump操作，默认关闭，如需开启可在平台 "全局配置->内存Dump" 中开启（该功能会触发JVM STW，请根据实际情况使用）
   * 启用后可在平台 "应用与微服务->诊断工具" 中创建内存Dump，内存Dump文件默认存储在服务器本地，可以通过选择转储服务器进行转储
3. 支持跨应用追踪黑白名单，可在平台 "应用与微服务->配置->系统设置/应用设置->事务" 中进行配置
   * 如果平台不支持配置可以在探针中做以下配置（在黑白名单配置中，白名单优先级高于黑名单）
     - 跨应用追踪黑白名单功能开关，开启配置即可使用此功能，具体配置如下：
        ```
        # 跨应用追踪黑白名单功能，默认禁用
        # 设置为true后，跨应用追踪黑名单配置和跨应用追踪白名单配置生效
        # default: false
        action_tracer.external.enabled=false
        ```
     - 跨应用追踪黑名单配置，该配置匹配的外部调用请求将不会写Tingyun Header，具体配置如下：
        ```
        # 可分为3段进行配置：
        # <PROTOCOL>:// ，外部请求的协议，可根据探针上报的PROTOCOL进行配置， 如：http://
        # <IP>:<PORT> ，外部请求的目标地址，也可以单独填写 <IP> 或 :<PORT>，其中 <IP> 支持正则匹配，以^开头$结尾表示为正则匹配。如：192.168.10.10:8080,127.0.0.1,^host-\d+$,:8080 
        # /<PATH> ，外部请求的路径，匹配方式为startWith，如：/query
        action_tracer.external.excludes=<PROTOCOL>://<IP>:<PORT>/<PATH>,<PROTOCOL>://<IP>:<PORT>/<PATH>,...
        ```
     - 跨应用追踪白名单配置，只有该配置匹配的外部调用请求才会写Tingyun Header，具体配置如下：
        ```
        # 注：跨应用追踪白名单优先级大于跨应用追踪黑名单，配置了跨应用追踪白名单后，跨应用追踪黑名单将不再生效
        # 可分为3段进行配置：
        # <PROTOCOL>:// ，外部请求的协议，可根据探针上报的PROTOCOL进行配置， 如：http://
        # <IP>:<PORT> ，外部请求的目标地址，也可以单独填写 <IP> 或 :<PORT>，其中 <IP> 支持正则匹配，以^开头$结尾表示为正则匹配。如：192.168.10.10:8080,127.0.0.1,^host-\d+$,:8080 
        # /<PATH> ，外部请求的路径，匹配方式为startWith，如：/query
        action_tracer.external.includes=<PROTOCOL>://<IP>:<PORT>/<PATH>,<PROTOCOL>://<IP>:<PORT>/<PATH>,...
        ```
4. 探针熔断支持进程CPU使用率，默认配置：
   * CPU使用率达到 80% 时触发探针采样
   * CPU使用率达到 90% 时触发探针熔断
5. 支持数据库连接池，适配 com.oracle.database.jdbc:ucp (21.1.0.0 ~ 21.9.0.0)
6. 支持数据库连接池，适配 org.apache.tomcat:tomcat-jdbc (7.0.19 ~ 10.1.8)
7. 支持Redis连接池，适配 org.redisson:redisson (3.11.1 ~ 3.16.0)
8. 支持Redis连接池，适配 redis.clients:jedis (3.6.0 ~ 3.9.0)
9. 支持Cassandra，适配 com.datastax.oss:java-driver-core (4.0.0 ~ 4.15.0)
10. 支持Spring @Async注解，适配 org.springframework:spring-context (3.1.0 ~ 4.0.9)
11. 支持JettyClient，适配 org.eclipse.jetty:jetty-client (9.4.35.v20201120 ~ 9.4.50.v20221201)
12. 支持SOFARPC，适配 com.alipay.sofa:sofa-rpc-all (5.3.1 ~ 5.9.2)

##### 修复
1. 修复Redisson部分操作无法采集Key的问题
2. 修复在同步线程的情况下Trace的执行时间和root方法的执行时间存在偏差的问题

##### 优化
1. 支持在没有开启异常堆栈采集的情况下采集错误堆栈，包括日志中的错误堆栈
2. 重构Dubbo插件，支持采集异步Callback的性能数据，解决Client端外部服务IP采集不准确的问题
3. 全栈快照支持以json的形式发送快照数据
4. 优化探针，避免触发DNS查询
5. 对tingyun.properties中数值的配置读取时进行去空格处理
6. 为避免Reactor Hook自身线程切换导致应用block()发生异常的问题(详见https://github.com/reactor/reactor-core/issues/3450)，默认禁用Reactor插件。如没有该异常的场景，可以在tingyun.properties中修改以下配置启用插件：
    ```
    class_transformer.tingyun-reactor-core-plugin-3.1.0.enabled=true
    class_transformer.tingyun-reactor-core-plugin-3.1.8.enabled=true
    class_transformer.tingyun-reactor-core-plugin-3.4.enabled=true
    ```
7. 优化跨应用追踪配置，关闭后将不再写Header

###### 兼容
| Java Agent | AgentCollector    | 平台       | 备注                                              |
|------------|-------------------|----------|:------------------------------------------------|
| 3.6.6      | 3.6.6.1+          | 3.6.7+   | 支持跨应用追踪黑白名单、内存Dump及内存诊断            | 
| 3.6.6      | 3.6.5.1+          | 3.6.5+   | 兼容Skywalking协议，支持Collector高可用                   | 
| 3.6.6      | 3.6.5.1+          | 3.6.2+   | 支持全栈快照V2协议                                      | 
| 3.6.6      | 3.6.4+            | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照                           | 
| 3.6.6      | 3.6.1.2+          | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.6      | 3.5.4.1 ~ 3.6.1.1 | 3.5.4.0+ |                                                 |


#### 2023-03-09 *Version:3.6.5.3*

##### 修复  
1. 修复业务线程快速退出时全栈快照功能可能停止的问题
2. 修复执行线程剖析后有一个残留线程的问题
3. 修复线程剖析功能无法取消的问题

###### 兼容
| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.5.3     | 3.6.5.1+        | 3.6.5+   | 兼容Skywalking协议，支持Collector高可用  | 
| 3.6.5.3     | 3.6.5.1+        | 3.6.2+   | 支持全栈快照V2协议 | 
| 3.6.5.3     | 3.6.4+          | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照 | 
| 3.6.5.3     | 3.6.1.2+        | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.5.3     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2023-02-07 *Version:3.6.5.2*

##### 修复  
1. 修复无事务Trace数据采集不全的问题
2. 修复无事务Trace在嵌套调用深度达到20后出现栈溢出的问题
3. 修复在使用Reactor-core 3.1.0.RELEASE ~ 3.1.7.RELEASE的情况下，调用publish、replay方法后出现类转换错误的问题 

###### 兼容
| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.5.2     | 3.6.5.1+        | 3.6.5+   | 兼容Skywalking协议，支持Collector高可用  | 
| 3.6.5.2     | 3.6.5.1+        | 3.6.2+   | 支持全栈快照V2协议 | 
| 3.6.5.2     | 3.6.4+          | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照 | 
| 3.6.5.2     | 3.6.1.2+        | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.5.2     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2023-01-04 *Version:3.6.5.1*

##### 修复  
1. 修复在Apache Dubbo Callback模式下,回调跨应用不正确的问题  
2. 修复在被内存限制探针无法启动的情况下,Starter日志文件名格式不正确的问题

##### 优化
1. 优化高并发情况下事务入口的锁竞争,减少对请求响应时间的影响

###### 兼容
| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.5.1     | 3.6.5.1+        | 3.6.5+   | 兼容Skywalking协议，支持Collector高可用  | 
| 3.6.5.1     | 3.6.5.1+        | 3.6.2+   | 支持全栈快照V2协议 | 
| 3.6.5.1     | 3.6.4+          | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照 | 
| 3.6.5.1     | 3.6.1.2+        | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.5.1     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2022-12-08 *Version:3.6.5*

##### 新增
1. 支持Collector高可用，自动连接可访问的Collector
2. 兼容Skywalking的跨应用拓扑协议，此功能需要使用3.6.5版本的平台，在Collector端的collector.properties里增加以下配置开启Skywalking兼容
   ```
     tracing.vendor=skywalking
   ```
   * 注：修改完collector.properties后需要重启Collector，连接Collector的探针也需要重启
3. 支持ResponseBody数据采集，该功能默认通过全量参数配置。如需启用可以在tingyun.properties中配置：                
   ```
     action_tracer.capture_full_parameters=true
   ```
   如需单独关闭ResponseBody的采集，可以在tingyun.properties中配置：
   ```
     action_tracer.capture_response_body_enabled=false
   ```
   注：
   
   * 配置数据项或用户溯源时，配置的Key为“ResponseBody”
   * 默认请求最大长度为2048，可配置最大采集长度为10240个字符，超出后进行截取，并在末尾补充({0} more chars)，{0}表示多少字符被忽略 ，如需修改，可以在tingyun.properties中修改以下配置：
     
     ```
        max_request_parameter_size=2048
     ```
     
4. 支持数据库类型以别名的方式命名，如需使用可以在tingyun.properties中配置
   ```
    action_tracer.database_alias_filter=数据库别名//hostname:port,ip:port;数据库别名//ip:port,ip:port
   ```
   * 配置说明：hostname、ip默认匹配方式为startsWith，如果需要以正则匹配需要以 “^” 开头，一个别名下有多个ip:port以 “,” 分割，多个数据库别名以 “;” 隔开
   * 配置举例：OpenGauss//192.168.2.213:5432,192.168.2.102;GoldenDB//10.128.2.95,^.*golden_server:3306
        - 如果数据库目标地址为192.168.2.213:5432或ip为192.168.2.102则数据库类型为OpenGauss
        - 如果数据库ip为10.128.2.95或正则匹配^.*golden_server:3306则数据库类型为GoldenDB
5. 探针启动时增加内存限制，默认堆最大内存低于400MB不进行嵌码启动
    * 该功能默认启用，如需关闭则可以在tingyun.properties中修改以下配置：
    ```
        agent_start_check.enabled=false
    ```
    * 如需修改堆内存限制值，可以在tingyun.properties中修改以下配置(单位MB)：
    ```
        agent_start_check.min_memory=400
    ```
6. 数据项和用户溯源支持采集数组数据
    * 数据项默认最大采集长度为2048个字符。如需更改，可以在tingyun.properties中修改以下配置(需要重启才能生效)：
    ```
        data_item.max_length=2048
    ```
    * 用户溯源默认最大采集长度50个字符。如需更改，可以在tingyun.properties中修改以下配置(需要重启才能生效)：
    ```
        user_info.max_length=50
    ```
7. 支持 org.elasticsearch:elasticsearch (7.3.0 ~ 7.17.7)
8. 支持 org.elasticsearch.client:elasticsearch-rest-high-level-client (7.5.0 ~ 7.17.7)
9. 支持 com.ibm.mq:com.ibm.mq.allclient (9.0.4.0 ~ 9.3.0.1)
10. 支持 org.redisson:redisson (3.13.0 ~ 3.17.7)
11. 支持 org.springframework.cloud:spring-cloud-circuitbreaker-resilience4j (1.0.0.RELEASE ~ 2.1.5)
12. 支持 org.quartz-scheduler:quartz (1.3.4 ~ 1.8.6)
13. 支持 io.vertx:vertx-core (3.8.0 ~ 3.8.5)
14. 支持 org.apache.kafka:kafka_2.11 (0.10.0.0 ~ 0.10.2.2)
15. 支持 com.xuxueli:xxl-job-core (1.9.0 ~ 2.3.1)
16. 支持 宝兰德中间件 (9.5.2)
17. 支持 中创中间件 (9.1)
18. 支持 TongWeb7 数据库连接池
19. 支持 Proxool 连接池 (0.9.1)
20. 支持 Undertow (1.0.0.Final ~ 2.2.21.Final)

##### 修复
1. 修复Redisson使用批量命令的情况下采集错误的问题
2. 修复日志溯源中无事务的情况下输出null的问题
3. 修复系统时间早于extensions目录下插件的修改时间时，探针重复加载导致应用CPU升高的问题
4. 修复TongWeb容器下采集不到端口的问题
5. 修复gRPC下采集不到快照数据的问题
6. 修复HttpClient5插件获取不到schema的问题
7. 修复日志溯源与Skywalking不兼容的问题
8. 修复Resteasy使用Netty作为底层容器时无法正常回写跨应用头的问题
9. 默认禁用Reactor-mysql插件，该插件在配置连接池后数据库调用会进行批量执行，数据采集无法准确定位到相应的Trace

##### 优化
1. 优化全栈快照，降低Collector的CPU使用率
2. 优化连接池数据，减少重复注册数据
3. 重构OkHttp插件，降低CPU使用率，完善异常采集
4. 重构AsyncHttpClient，完善异常采集
5. 重构Kafka插件，支持异常采集
6. 优化Reactor-core插件，降低内存使用率，默认启用
7. 优化Lettuce插件，降低CPU使用率，完善异常采集
8. 统一Debug日志输出，去除-Dtingyun.debug=true的配置
9. 重构Dubbo插件， 兼容3.x版本
10. 优化Filter插件，减少重复的Tracer创建
11. 优化MQ插件，关闭MQ消费端监控后生产端不写跨应用头
12. 优化Class适配缓存，减少内存使用率
13. 支持Jdbc executeLargeUpdate的性能数据采集
14. 调整Http调用返回的状态码小于400的视为正常请求

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.5     | 3.6.5.1+        | 3.6.5+   | 兼容Skywalking协议，支持Collector高可用  | 
| 3.6.5     | 3.6.5.1+        | 3.6.2+   | 支持全栈快照V2协议 | 
| 3.6.5     | 3.6.4+          | 3.6.2+   | 支持微秒、指定业务系统功能，不支持全栈快照 | 
| 3.6.5     | 3.6.1.2+        | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.5     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2022-10-21 *Version:3.6.4.2*

##### 新增
1. 支持 org.apache.kafka:kafka-clients (0.11.0.0 ~ 1.1.1)
小
##### 修复
1. 修复OJDBC驱动在使用PreparedStatement场景下，采集不到SQL的问题
2. 修复Netty框架在Oracle JDK(16 ~ 18)或OpenJDK(16 ~ 18)环境下，应用启动失败的问题

##### 优化
1. 优化神通数据库在使用PreparedStatement场景下，采集不到SQL的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.4.2     | 3.6.4+         | 3.6.2+   | 支持全栈快照、微秒、指定业务系统功能 | 
| 3.6.4.2     | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.4.2     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2022-09-22 *Version:3.6.4.1*

##### 修复
1. 修复在探针熔断采样或后台任务下调用Spring @Async注解的事务名不正确的问题
2. 修复无事务Trace(非Web请求且无事务入口的Trace)遇到异常情况下，内存不释放的问题
3. 修复探针启动过程中出现空指针日志的问题

##### 优化
1. 优化Reactor(reactor-core插件默认关闭)数据采集，降低CPU使用率

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.4.1     | 3.6.4+         | 3.6.2+   | 支持全栈快照、微秒、指定业务系统功能 | 
| 3.6.4.1     | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.4.1     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2022-08-03 *Version:3.6.4*

##### 新增
1. 支持 Mongodb 连接池 (3.5.0 ~ 4.2.3)
2. 支持 c3p0 连接池 (0.9.0-pre5 ~ 0.9.0.4, 0.9.2-pre2-RELEASE ~ 0.9.5)
3. 支持 Tomcat 5 线程池
4. 支持 com.datastax.cassandra:cassandra-driver-core (2.0.7 ~ 2.0.12.3, 2.1.2 ~ 3.11.2)
5. 支持 dev.miku:r2dbc-mysql (0.8.1.RELEASE ~ 0.8.2.RELEASE)
6. 支持 io.lettuce:lettuce-core (6.0.0.RELEASE ~ 6.1.8.RELEASE)
7. 支持 io.projectreactor:reactor-core (3.1.0.RELEASE ~ 3.4.17)
    * 插件默认禁用，如需启用，在tingyun.properties中增加以下配置(需重启应用)：
    * 启用插件后，CPU会有较为明显的增幅，请根据实际需要开启
    ```
        class_transformer.tingyun-reactor-core-plugin-3.1.enabled=true
        class_transformer.tingyun-reactor-core-plugin-3.4.enabled=true
    ```
8. 支持 redis.clients:jedis (3.6.0 ~ 3.9.0)
9. 支持 org.jboss.resteasy:resteasy-core (4.4.0.Final ~ 5.0.3.Final)
10. 支持 io.grpc:grpc-core (1.6.0 ~ 1.18.0, 1.22.0 ~ 1.29.0)
11. 支持 Apache Log4j (2.13.2 ~ 2.18.0) 异步模式的日志溯源
12. 支持Oracle Hotspot JVM、OpenJDK JVM的对象增长速度和晋升速度的采集(单位：MB/s)
13. 支持东方通(TongWeb 7)中间件数据采集

##### 改进
1. 支持 JDK15、JDK16、JDK17、JDK18
2. 支持Spring WebMVC中ContentType为application/text、text/plain的Request Payload数据采集
3. 日志溯源自动注入，不需要修改日志配置文件，同时也兼容以前的日志配置
    * 默认的日志输出格式：
    ```
        [tingyun.app_id:应用ID,tingyun.trace_id:TRACEID,tingyun.span_id:SPANID]
    ```
4. 优化探针嵌码性能
5. 优化Netty插件，默认启用
6. 支持数据项或用户溯源的Getter chain配置父类方法
7. 支持OceanBase、OpenGauss、ClickHouse数据库识别
8. 优化OkHttp插件，支持采集异常及超时情况下的拓扑数据

##### 修复
1. 修复自动应用命名失效的问题
2. 修复HttpURLConnection使用HTTPS协议时，跨应用关联失败的问题
3. 修复SpringBoot应用使用Tomcat容器发生异常后，探针没有采集到业务异常的问题
4. 修复探针重复init，导致应用内存溢出的问题
5. 修复用户溯源或数据项配置为采集This对象不生效的问题
6. 修复配置用户溯源或数据项配置Getter chain为toString不生效的问题
7. 修复Redisson使用Object Key的情况下采集不到数据的问题

###### 兼容
| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.4     | 3.6.4+         | 3.6.2+   | 支持全栈快照、微秒、指定业务系统功能 | 
| 3.6.4     | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.4     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2022-07-26 *Version:3.6.3.3*

##### 修复
1. 修复在JDK9 ~ 14下采集不到数据库数据的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.3.3     | 3.6.4+         | 3.6.2+   | 支持全栈快照、微秒、指定业务系统功能 | 
| 3.6.3.3     | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.3.3     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2022-05-18 *Version:3.6.3.2*

##### 修复
1. 修复单次请求里大量异步调用数据采集导致内存溢出的问题
2. 修复Wildfly下未采集到500异常请求的问题
3. 修复Tomcat产生500异常后无法生成拓扑数据的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.3.2     | 3.6.4+         | 3.6.2+   | 支持全栈快照、微秒、指定业务系统功能 | 
| 3.6.3.2     | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.3.2     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2022-04-01 *Version:3.6.3.1*

##### 新增
1. 支持com.squareup.okhttp:okhttp (2.7.0 ~ 2.7.5)
2. 支持Spring Async (4.2.0.RELEASE ~ 5.3.17)

##### 改进
1. 优化 Spring Cloud Gateway 超时异常采集
2. 支持Containerd容器微服务识别

##### 修复
1. 修复开启Kafka消费功能后，无消息消费时产生快照数据的问题
2. 修复OpenFeign插件无跨应用的问题
3. 修复无事务Trace独占时间计算错误、组件信息归类错误的问题
4. 修复Dubbo外部服务调用错误采集不全的问题
5. 修复Dubbo服务异常未采集成事务错误的问题
6. 修复Reactor Netty请求超时的情况下没有采集到外部服务调用的问题
7. 修复Jar Class信息采集导致应用性能下降的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.3.1     | 3.6.4+         | 3.6.2+   | 支持全栈快照、微秒、指定业务系统功能 | 
| 3.6.3.1     | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.3.1     | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2021-12-29 *Version:3.6.3*

##### 新增
1. 支持全栈快照，默认开启。如需调整可在 "APM->配置->系统设置->性能诊断" 中进行调整，
   * 支持的快照模式:
       - 触发采集模式，根据配置的慢请求占比决定请求是否进行快照采集。默认触发条件：1分钟内10%的慢请求(总次数>20)
       - 固定周期采集模式，根据配置的固定时间周期进行快照采集。默认触发条件：1分钟内采集10个全栈快照
       - 强制采集模式，默认关闭，根据配置的慢阈值进行快照采集。默认触发条件：请求执行时间大于3倍慢请求阈值
2. 采集数据精度精确至微秒
3. 支持南通数据库数据采集
4. 支持OpenJ9内存数据采集
5. 支持 io.projectreactor.netty:reactor-netty (1.0.0 ~ 1.0.14)
6. 支持指定业务系统，默认业务系统为default，如需修改，在tingyun.properties里修改以下配置：
  ```
    default_business_system=default
  ```
   或在JVM启动参数中增加以下配置：
   ```
    -Dtingyun.default_business_system=default
   ```
7. 支持 WebSphere 连接池 (7.x)
8. 支持HttpClient、OkHttp、UrlConnection、Feign、Reactor Netty等基于HTTP协议的Response Code采集，RPC（如Dubbo）框架暂不支持，数据可在追踪详情Call Table中查看

##### 改进
1. 达梦、神通 数据库URL中没有数据库名时，使用默认名称作为数据库名
2. 优化Jersey-Client插件的异常处理
3. 优化探针性能

##### 修复
1. 修复在命令行中添加数值类型的配置项，探针启动失败的问题
2. 修复线程池采集过程中，在并发的情况下报ConcurrentModificationException
3. 修复WebClient未采集到超时异常的问题及超时无跨应用问题
4. 修复WebFlux、Zuul插件事务命名在后端无法聚合的问题
5. 修复OpenJ9启动失败的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.3      | 3.6.4+         | 3.6.2+   | 支持全栈快照、微秒、指定业务系统功能 | 
| 3.6.3      | 3.6.1.2+       | 3.6.2+   | AgentCollector 3.6.1.2变更了数据协议，需要使用3.6.2及以上版本的平台 |
| 3.6.3      | 3.5.4.1 ~ 3.6.1.1| 3.5.4.0+ | |


#### 2021-12-22 *Version:3.6.2.4*

##### 修复
1. 修复在高并发情况下性能数据发送不全的问题 
2. 修复在使用当当的ShardingJdbc做数据库主从或数据库分片的场景下应用调用数据库报错的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.2.4    | 3.5.4.1+      | 3.5.4.0+ | 推荐使用AgentCollector 3.6.2.1+，修复异步场景下，方法调用顺序异常展示的问题 |


#### 2021-12-06 *Version:3.6.2.3*

##### 修复
1. 修复动态修改应用名导致应用重嵌码的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.2.3    | 3.5.4.1+      | 3.5.4.0+ | 推荐使用AgentCollector 3.6.2.1+，修复异步场景下，方法调用顺序异常展示的问题 | 


#### 2021-11-05 *Version:3.6.2.2*

##### 修复
1. 修复JFinal框架Json序列化失败的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.2.2    | 3.5.4.1+      | 3.5.4.0+ | 推荐使用AgentCollector 3.6.2.1+，修复异步场景下，方法调用顺序异常展示的问题 | 


#### 2021-10-27 *Version:3.6.2.1*

##### 修复
1. 修复用户溯源采集结果写入Header超长导致应用报错的问题
* 默认限制50个字符。如需更改，在tingyun.properties中修改以下配置(需要重启才能生效)：
  ```
    user_info.max_length=50
  ``` 
  
##### 改进
1. 优化数据项采集长度。
* 默认限制2048个字符。如需更改，在tingyun.properties中修改以下配置(需要重启才能生效)：
   ```
    data_item.max_length=2048
   ```

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.2.1    | 3.5.4.1+      | 3.5.4.0+ | 推荐使用AgentCollector 3.6.2.1+，修复异步场景下，方法调用顺序异常展示的问题 | 


#### 2021-10-22 *Version:3.6.2*

##### 新增
1. 支持 org.apache.httpcomponents.client5:httpclient5 (5.0 ~ 5.1)
2. 支持 org.apache.httpcomponents:httpasyncclient (4.0 ~ 4.1.4)
3. 支持 org.asynchttpclient:async-http-client (2.1.0 ~ 2.12.3)
4. 支持 com.squareup.okhttp3:okhttp (3.14.0 ~ 3.14.9)
5. 支持
     - org.mongodb:mongo-java-driver (3.7.0 ~ 3.12.10)
     - org.mongodb:mongodb-driver-sync (3.7.0 ~ 4.3.2)
     - org.mongodb:mongodb-driver-async (3.7.0 ~ 3.12.10)
6. 支持 org.redisson:redisson (2.3.0 ~ 2.15.2)
7. 支持 
     - org.elasticsearch:elasticsearch (6.0.0 ~ 6.8.18)
     - org.elasticsearch.client:elasticsearch-rest-high-level-client (6.6.0 ~ 6.8.18)
       * 默认开启ElasticSearch Query DSL采集。如需关闭，可以在tingyun.properties中修改以下配置(需要重启才能生效)：
       ```
         es.capture_operation=false
       ``` 
       * 默认采集的ElasticSearch Query DSL长度为2000，超出后进行裁剪，并在末尾补充[{0} more chars]，{0}表示多少字符被截断。如需修改，可以在tingyun.properties中修改以下配置(需要重启才能生效)：
       ```
         action_tracer.insert_sql_max_length=2000
       ```
8. 支持 commons-dbcp:commons-dbcp (1.2 ~ 1.4)
9. 支持 org.apache.commons:commons-dbcp2 (2.0 ~ 2.9.0)
10. 支持 com.jolbox:bonecp (0.7.1.RELEASE & 0.8.0.RELEASE)
11. 支持 org.apache.httpcomponents:httpclient 连接池 (4.3 ~ 4.5.13)
12. 支持 WebSphere 连接池 (8.5)
13. 支持 org.apache.shiro:shiro-core (1.2.0 ~ 1.8.0) 用户信息的采集
    * 默认关闭。如需开启，可以在tingyun.properties中修改以下配置(需要重启才能生效)：
    ```
    class_transformer.tingyun-shiro-plugin-1.0.enabled=true
    ```
    * 配置用户溯源与数据项时，数据来源为 Servlet session attribute，Key为"TINGYUN_SHIRO_LOGIN_USER"
    
14. 支持Jvm SafePoint数据采集
15. 支持堆外内存(MappedByteBuffer,DirectByteBuffer)数据采集
16. 支持Spring Zuul 2.0.0.RELEASE ~ 2.2.9.RELEASE 事务命名
17. 支持忽略trace中独占时间小于指定时间的Span,仅支持Code类型。异常,异步,Database,NoSQL,MQ,POOL,External类型不会被忽略
    * 默认开启。如需关闭，可以在tingyun.properties中修改以下配置(需要重启才能生效)：
    ```
     action_tracer.reduce.enabled=false
    ``` 
    * 忽略指定时间内的方法调用，默认忽略0毫秒的方法调用(需要重启才能生效)：
    ```
     action_tracer.reduce.span_ignore_duration=0
    ```
    
18. 支持对指定数据接口开启审计模式，支持审计模式动态生效
    * 默认关闭。如需开启，可以在tingyun.properties中修改以下配置：
    ```
     audit_mode=true
    ``` 
    * 对指定数据接口开启审计模式，可配置一个或者多个数据接口，多个数据接口用逗号隔开，如需开启，可以在tingyun.properties中修改以下配置：
    ```
     audit_mode.interfaces=jvm,trace,jar,getCmd,hotspot,uploadFile,uploadProfile,redirect
    ```

##### 改进
1. 优化连接池，在高并发场景下导致应用访问变慢的问题
2. 增加事务名md5缓存，提升性能
3. 增加Jdbc url缓存，减少重复解析，提升性能
4. 优化CompletableFuture插件，减少无关方法嵌码
5. 优化资源保护或者熔断下，日志溯源获取到的事务ID一样的问题(优化为固定值:DUMMY_ACTION_GUID)

##### 修复
1. 修复IBM JDK CPU使用率获取失败的问题
2. 修复Hystrix异步线程获取spanId错误的问题
3. 修复Jedis，Lettuce，Redisson性能数据不准确的问题
4. 修复Jedis getResource方法调用异常，类转换失败的问题
5. 修复应用jar包无法上传的问题
6. 修复从Web request query parameter中采集数据乱码的问题
7. 修复用户溯源中包含中文时引发调用失败的问题
8. 修复Netty事务无法释放的问题
9. 修复WebSphere获取不到port的问题
10. 修复Wildfly获取不到port的问题
11. 修复HttpURLConnection一次调用采到多次跨应用的问题
12. 修复探针在未开启SSL且应用系统中缺少SSL库时启动报错的问题
13. 修复Okhttp(3.4.0 ~ 3.4.2)字节码错误的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                  |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.2      | 3.5.4.1+      | 3.5.4.0+ | 推荐使用AgentCollector 3.6.2.1+，修复异步场景下，方法调用顺序异常展示的问题 | 


#### 2021-08-27 *Version:3.6.1.7*

##### 修复
1. 修复使用Alibaba Druid连接池，在高并发场景下导致应用访问变慢的问题
2. 修复单次请求span个数超过阈值（默认3000）时，事务性能指标归类错误的问题
3. 修复跨应用请求中，Response Body过大，可能导致内存溢出的问题
4. 修复应用客户端使用WebSocket调用Webflux服务端，可能导致内存溢出的问题
5. 修复Weblogic数据库连接池信息采集不到的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                 |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.1.7    | 3.5.4.1+       | 3.5.4.0+ |  |


#### 2021-07-28 *Version:3.6.1.6*

##### 修复
1.移除druid连接池插件

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                 |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.1.6    | 3.5.4.1+       | 3.5.4.0+ |  |


#### 2021-07-14 *Version:3.6.1.5*

##### 修复

1.修复Sybase,Informix数据库相关数据采集的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                 |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.1.5    | 3.5.4.1+       | 3.5.4.0+ |  |

#### 2021-06-18 *Version:3.6.1.4*

##### 修复

1.修复使用jconn驱动连接Sybase数据库，产生StackOverflowError，导致应用访问失败的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                 |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.1.4    | 3.5.4.1+       | 3.5.4.0+ |  |

#### 2021-05-23 *Version:3.6.1.3*

##### 修复

1.修复Apache Dubbo 应用间调用的层级数大于2，且被调用的dubbo服务使用rest协议调用其他dubbo服务时，发生异常导致业务访问失败的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                 |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.1.3    | 3.5.4.1+       | 3.5.4.0+ |  |

#### 2021-05-20 *Version:3.6.1.2*

##### 修复

1. 修复RocketMQ Producer端在高并发情况下可能出现的消息发送失败问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                 |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.1.2    | 3.5.4.1+       | 3.5.4.0+ |  |

#### 2021-05-11 *Version:3.6.1.1*

##### 修复

1. 修复Apache Dubbo 应用间调用的层级数大于2时，跨应用相关数据不准确的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                 |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.1.1    | 3.5.4.1+       | 3.5.4.0+ |  |

#### 2021-04-28 *Version:3.6.1*

##### 新增

1. 支持SpringSchedule 3.1.0.RELEASE ~ 5.3.5
2. 支持Jedis 3.0.0 ~ 3.5.2
3. 支持JedisPool 3.0.0 ~ 3.5.2 连接池
4. 支持Okhttp 4.4.0 ~ 4.9.1
5. 支持Spring Webflux 5.0.1.RELEASE ~ 5.3.5
6. 支持Spring WebClient 5.0.1.RELEASE ~ 5.3.5
7. 支持Dubbo 2.7.0 ~ 2.7.1
8. 支持Mule 3.6.0 ~ 3.7.0
9. 支持Nginx应用的拓扑识别
10. 支持Kubernetes管理的Docker 1.11 ~ ce-20 的数据采集
11. 支持后台任务中R2DBC-MySQL 0.8.0.RELEASE ~ 0.8.1.RELEASE 的数据采集
12. 支持Spring Webmvc 3.2.0.RELEASE ~ 5.3.5 Request Payload 的数据采集

注:

* 采集Request Payload对CPU消耗较大，谨慎开启
* 配置数据项与用户溯源时，配置key为"Payload"
* 默认关闭。如需开启采集，可以在tingyun.properties中修改以下配置：

```
   action_tracer.capture_full_parameters=true
``` 

* 默认请求最大长度为2048，可配置最大采集长度为10240个字符，超出后进行截取，并在末尾补充({0} more chars)，{0}表示多少字符被忽略 ，如需修改，可以在tingyun.properties中修改以下配置：

```
   max_request_parameter_size=2048
```

13. 支持线程池数据采集(包括JDK线程池与容器线程池)

- 默认采集线程池个数200，如需修改，可以在tingyun.properties中修改以下配置：

   ```
     thread_pool.max_size=200
   ```

##### 改进

1. 优化浏览器嵌码功能，防止某些场景下出现页面乱码和白屏等问题
2. 优化trace发送方式，支持批量发送，以提升探针性能

##### 修复

1. 修复数据库JDBC的性能指标中Unknown问题
2. 修复从环境变量中获取app_name与license_key失败的问题
3. 修复RocketMQ消费者实例命名错误的问题
4. 修复HttpClient，OkHttpClient，AsyncHttpClient等组件在某些场景Host与port命名为Unknown问题
5. 修复事务名中包含分号";"分隔符的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                 |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.1      | 3.5.4.1+       | 3.5.4.0+ |  |

#### 2021-03-23 *Version:3.6.0.1*

##### 修复

1. 修复jdbc batch插件在某些场景下导致应用访问失败的问题

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                 |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.0.1      | 3.5.4.1+       | 3.5.4.0+ | 支持SQL混淆逻辑后置到Agent Collector，从而优化探针性能 |

#### 2021-01-25 *Version:3.6.0*

##### 新增

1. 支持Lettuce 5.0.0.RELEASE ~ 5.3.6.RELEASE

##### 改进

1. 支持Slf4j、Logback、Log4j错误日志格式化输出采集
2. SQL混淆逻辑后置到Agent Collector
3. 支持SocketInputStream数据采集

- 默认禁用SocketInputStream相关Plugin，如有SocketInputStream使用场景，在tingyun.properties中修改以下配置

  ```
   class_transformer.tingyun-java.socket-input-stream-plugin.enabled=true
  ```

4. Trace数据支持异步发送

- 默认为关闭，如需开启采集，可以在tingyun.properties中修改以下配置：

  ```
   trace_send.async=true
  ```

- 适用于数据发送丢失，数据积压导致内存增加的场景

5. Trace数据发送超时时间设置，单位为秒

- 默认1秒，如需修改，可以在tingyun.properties中修改以下配置：

  ```
   trace_send.timeout=1
  ```

- 适量修改该值，可以规避由于网络抖动造成的数据发送失败的场景

6. Trace数据支持Gzip压缩发送

- 默认为关闭，如需开启采集，可以在tingyun.properties中修改以下配置：

  ```
   trace_send.gzip=true
  ```

- 适用于对网络带宽要求比较高的场景，开启Gzip压缩，能够大大减少网络流量的传输，降低对带宽的需求；同时带来的代价是额外的cpu/内存资源消耗

###### 兼容

| Java Agent | AgentCollector | 平台     | 备注                                                 |
| ---------- | -------------- | -------- | :--------------------------------------------------- |
| 3.6.0      | 3.5.4.1+       | 3.5.4.0+ | 支持SQL混淆逻辑后置到Agent Collector，从而优化探针性能 |

#### 2020-12-09 *Version:3.5.3*

##### 新增

1. 支持Dubbox 2.8.0 ~ 2.8.4
2. 支持数据库连接池c3p0(0.9.1 ~ 0.9.1.2)的数据采集

##### 改进

1. 支持负载组件(如：Nginx)通过Cookie保持探针与Collector会话的方式
2. 支持SQLServer数据库JDBC URL解析

##### 修复

1. 修复Spymemcached插件引发的类重复定义的问题
2. 修复解析Oracle数据库JDBC URL失败的问题
3. 屏蔽对Cglib动态生成类信息的上报

###### 兼容

| Java Agent | AgentCollector | 平台      | 备注                                       |
| ---------- | -------------- | -------- | :----------------------------------------  |
| 3.5.3      | 3.5.3+         | 3.5.4.0+ | 支持使用新版错误分析功能                          |
|            | 3.5.1+         | 3.4.0+   | 保障探针与平台时间同步                        |
|            | 3.4.0+         | 3.4.0+   | 支持采集Request parameters（不包含POST Body）    |

#### 2020-10-31 *Version:3.5.1*

##### 新增

1. 支持JDK9、JDK10、JDK11、JDK12、JDK13、JDK14

##### 改进

1. 自动检测容器，无需手动屏蔽部分容器的CLassLoader嵌码
2. 适配OneAgent，自动调整日志数据目录及实例命名

##### 修复

1. 修复因Loaded Classes数量过多导致Class信息上传不全的问题
2. 修复配置用户溯源字符串截取导致探针异常的问题
3. 修复不支持Browser探针的Transaction ID的问题
4. 修复因设置实例名导致无法获取实例端口的问题
5. 修复在Browser嵌码关闭的状态下，仍然消耗CPU的问题
6. 修复gRPC流模式不能跨应用的问题
7. 修复AsyncHttpClient无跨应用的问题
8. 修复因获取hostname导致线程卡住的问题
9. 修复在JDK11下CompletableFuture插件无法释放事务的问题
10. 修复访问SpringController默认页面时事务命名不正确的问题
11. 修复获取数据库连接信息异常导致应用访问失败的问题
12. 移除对Spymemcached的支持(会影响Spymemcached方式的性能数据的采集),以避免Spymemcached插件引发类加载错误导致的应用启动失败

###### 兼容

| Java Agent | AgentCollector | 平台      | 备注                                       |
| ---------- | -------------- | -------- | :----------------------------------------  |
| 3.5.1      | 3.5.3+         | 3.5.4.0+ | 支持使用新版错误分析功能                          |
|            | 3.5.1+         | 3.4.0+   | 保障探针与平台时间同步                        |
|            | 3.4.0+         | 3.4.0+   | 支持采集Request parameters（不包含POST Body）    |

#### 2020-10-20 *Version:3.4.8*

##### 新增

1. 采集全量Request parameters（不包含POST Body）

注:

* 默认最大采集长度为512个字符，可配置最大采集长度为2048个字符，如需更改，可以在tingyun.properties中修改以下配置

```
  action_tracer.capture_full_parameters_length=512
```

* 该功能默认关闭。如需开启采集，可以在tingyun.properties中修改以下配置：

```
   action_tracer.capture_full_parameters=true
```

##### 改进

1. 支持新版错误分析
2. 内置NTP服务，保障探针与平台时间同步
3. 优化探针采集异常栈过深导致的性能问题， 默认限制采集最大异常栈深由2000改为100。如需更改，可以在tingyun.properties中修改以下配置：

```
    error_collector.max_stack_depth=100 
```

###### 兼容

| Java Agent | AgentCollector | 平台      | 备注                                       |
| ---------- | -------------- | -------- | :----------------------------------------  |
| 3.4.8      | 3.5.3+         | 3.5.4.0+ | 支持使用新版错误分析功能                          |
|            | 3.5.1+         | 3.4.0+   | 保障探针与平台时间同步                        |
|            | 3.4.0+         | 3.4.0+   | 支持采集Request parameters（不包含POST Body）    |

#### 2020-08-31 *Version:3.4.7*

##### 修复

1.修复Oracle JDBC URL为TNSName格式情况下导致应用访问异常的问题

###### 兼容

| AgentCollector | 平台    |
| ------         | ------  | 
| 3.4.0+         | 3.4.0+  |

#### 2020-07-10 *Version:3.4.6*

##### 修复

1.移除对Spring Webflux的支持 (会影响对Spring Webflux, Spring Gateway性能数据的采集),以避免在Spring Webflux 5.1.0.RELEASE ~
5.1.2.RELEASE，5.1.7.RELEASE ~ 5.1.8.RELEASE 下探针引发应用不可用的问题

###### 兼容

| AgentCollector | 平台    |
| ------         | ------  | 
| 3.4.0+         | 3.4.0+  |

#### 2020-04-28    *Version:3.4.5*

###### 新增

1. 支持事务级线程剖析
2. 支持方法参数命名事务
3. 支持Jersey Client 2.0 ~ 2.30.1
4. 支持Spring Gateway 2.1.4.RELEASE ~ 2.2.2.RELEASE
5. 支持Spring Webflux 5.1.11.RELEASE ~ 5.2.5.RELEASE

###### 修复

1. 修复在Webflux下browser探针到后端的跨应用不正确的问题
2. 修复ReactorNetty拓扑展示不正确的问题
3. 修复ActiveMQ下没有采集字节数的问题及生产者获取不到ip端口的问题
4. 修复在调用HttpServletRequest.getParameter之前，URL参数命名事务无法使用URL参数的问题
5. 修复在SpringBoot的NettyWebServer下获取不到端口的问题
6. 修复当探针放在根目录下，探针无法启动的问题
7. 修复在Jetty7下获取不到Response状态码的问题
8. 修复在IBM J9下探针启动失败的问题
9. 修复WebLogic 10.3.6无法获取用户标识的问题
10. 修复在Dubbo的rest协议下业务方法调用失败的问题

###### 兼容

| AgentCollector | 平台  |
| ----           | ----  |
| 3.4.0          | 3.4.0 |

#### 2020-03-09    *Version:3.4.0*

###### 新增

1. 支持OneAgent工作模式，详见《OneAgent部署&管理手册》
2. 支持以下数据库连接池数据采集
    * Druid 0.2.4 ~ 1.1.21
    * Hikaricp 2.4.0 ~ 3.4.2
    * c3p0 0.9.5.1 ~ 0.9.5.5
    * WebLogic 10.3.6, 12.1, 12.2
3. 支持Jedis 2.6.3 ~ 2.10.2 连接池数据采集
4. 支持Alibaba RocketMQ 3.2.6，3.4.6
5. 支持Apache RocketMQ 4.4.0 ~ 4.6.1
6. 支持Kafka 2.0.x ~ 2.4.x
7. 支持Spring Kafka 2.2.0.RELEASE ~ 2.4.4.RELEASE
8. 支持Redisson 2.9.x ~ 2.15.x, 3.5.x ~ 3.12.x
9. 支持RabbitMQ 5.0.x ~ 5.8.x
10. 支持Spring RabbitMQ 2.2.0.RELEASE ~ 2.2.5.RELEASE

###### 改进

1. 为保证内存控制及事务采集达到最佳状态，资源保护功能在采样状态下自动调整事务采集频率。(注：报表上的事务采样率不再生效)
2. 当事务trace数超过3000后，优化内存继续占用的情况
3. 重构Alibaba Dubbo，适配 2.0.10+ (RMI协议 2.6.0+)
4. 重构Apache Dubbo，适配 2.7.2+（不支持RMI协议)

###### 修复

1. 修复在WebLogic下输出页面第一次不带Header时无法browser嵌码的问题
2. 修复探针采集不到通过defineClass方法生成的class信息的问题
3. 修复在个别Tomcat启动时报找不到Log方法的问题
4. 修复应用中使用Dubbo 2.7.2及以上版本，无法获取正确返回值的问题
5. 修复WebSphere 8没有跨应用的问题
6. 修复Jetty 6事务不释放的问题

#### 2020-02-04    *Version:3.3.3*

###### 新增

1. 支持Jdbc批量执行sql的性能采集

###### 改进

1. 溯源功能支持Logback(1.2+)、Log4j(1.2+)日志框架的异步模式
2. 针对多个应用进程共用一个探针的情况增加自动生成多日志目录的功能，默认不开启。如需开启，可以在tingyun.properties中增加以下配置：

```
    agent_log_auto_dir.enabled=true
```

注:

* 默认支持同时100个应用进程共用一个探针，如果需要修改，可以在配置文件中增加以下配置：

 ```
     agent_log_auto_dir.size=100
 ```

* 此功能不支持自动升级，需要手动更新探针目录并重启生效

###### 修复

1. 修复Browser嵌码中探针写入的Cookie被页面应用解码后，导致页面异常的情况
2. 修复单次请求中数据库调用次数超过事务深度限制后，部分临时数据仍在增加问题
3. 修复探针在SpringBoot的应用中启动后，无法上传部分classes信息的问题
4. 修复在业务系统拓扑中无法展示Dubbo跨应用调用关系的问题

#### 2019-11-04    *Version:3.3.1*

###### 新增

1. 支持Spring Gateway 2.0.0.RELEASE ~ 2.1.3.RELEASE
2. 支持Spring Webflux 5.0.4.RELEASE ~ 5.1.10.RELEASE (不支持 5.1.2.RELEASE, 5.1.7.RELEASE, 5.1.8.RELEASE)
3. 支持Okhttp 4.0.0 ~ 4.2.2

###### 改进

1. 针对WebSphere（IBM JDK）下探针无法启动的问题, 新增加Json协议(需配合3.3.1版本的Collector使用)发送数据, 如需开启Json协议数据, 可在tingyun.properties中增加以下配置:

```
    sendType=json
```

###### 修复

1. 修复探针采集异常栈及CauseBy过深导致内存占用过大的问题, 默认限制采集最大栈深2000
2. 修复应用使用Weblogic自带的数据库连接池, 探针采集不到sql的问题
3. 修复应用使用War包部署方式的情况下, 探针不上报Class信息的问题
4. 修复报表上自定义嵌码搜索类时显示的Cglib类, 屏蔽Cglib类信息
5. 修复子线程实例化后没有立即执行，异步事务可能关联不上的问题
6. 修复3.3.0探针在WebSphere 8.5上采集不到事务的问题
7. 修复3.3.0探针在Jetty6容器下事务无法释放的问题
8. 修复探针在ActiveMQ的ReplyTo场景下没有跨应用问题
9. 修复HttpClient3.1异常采集的位置和外部调用的位置不一致的问题

#### 2019-09-20    *Version:3.3.0*

###### 新增

1. 支持apache版本的Dubbo 2.7.2、2.7.3
2. 支持以下容器的Servlet3.0异步方式：
    * Tomcat 6.0.0 ~ 9.0.20
    * Jetty 8.0.0.M3 ~ 9.4.20.v20190813(不支持9.1.1v20140108, 9.3.0.x, 9.4.0.x)
    * Resin 4.0.09 ~ 4.0.62(不支持4.0.14， 4.0.15)
    * Wildfly 8.0.0.Final ~ 8.2.1.Final
    * Jboss 7.0.2.Final ~ 7.1.1.Final
    * Weblogic 12.2.1, 12.2.1.1, 12.2.1.2
    * Glassfish 3.1.1 ~ 4.1.2

###### 改进

1. 优化探针Metaspace使用情况
2. 实例端口初始化，优先容器端口，如无容器则取应用服务端口
3. 为防止Netty插件适配非容器场景后可能造成事务释放延迟或无事务，默认禁用Netty插件。如有使用Netty作为容器的场景，可在tingyun.properties中增加如下配置启用插件：

```
    class_transformer.tingyun-netty-plugin-3.2.5.enabled=true
    class_transformer.tingyun-netty-plugin-3.4.enabled=true
    class_transformer.tingyun-netty-plugin-3.8.enabled=true
    class_transformer.tingyun-netty-plugin-4.0.0.enabled=true
    class_transformer.tingyun-netty-plugin-4.0.8.enabled=true
```

###### 修复

1. 修复探针链接网络出现问题时日志输出到应用日志里的问题
2. 修复Oracle Jdk下Wildfly，Jboss因为未配置LogManager无法启动的问题
3. 修复Jdbc插件在某些应用中报找不到插件工具类的问题
4. 修复在Jboss7下报找不到探针Api类的问题
5. 修复对后台线程配置自定义嵌码并作为事务入口的情况下，事务命名为URI/的问题
6. 修复探针上报Jmx数据时有时无的问题
7. 修复HttpClient被并发使用时无跨应用的问题

###### 已知问题

1. 3.1.0 ~ 3.3.0 版本的探针暂不支持 WebSphere（IBM JDK），预计下个版本修复。  
   如果当前正在使用WebSphere（IBM JDK）建议使用3.0.1探针，对应的Agent Collector版本3.0.0，平台版本3.0.0
2. 如果子线程实例化后没有立即执行，可能出现异步事务关联不上的问题，预计下个版本修复

#### 2019-07-01    *Version:3.2.1*

###### 新增

1. 支持抓取JDBC驱动中的executeUpdate的受影响行数
2. 支持报表配置中的“忽略异常类”设置，可忽略事务中抛出的指定异常或错误

###### 改进

1. 修改上传JDBC数据库地址格式，目前采用IP地址方式，之前采用host name方式

###### 修复

1. 修复在某些情况下，数据库插件造成应用死锁的问题
2. 修复在资源保护或者探针未连接到Collector情况下，探针造成内存泄露的问题
3. 修复单个应用容器中部署多应用情况下，应用命名不正确的问题

###### 已知Bug

1. 应用开启Browser自动嵌码，Tomcat、Weblogic容器在Chunk输出页面的情况下可能引起页面白屏

#### 2019-05-20    *Version:3.2.0*

###### 新增

1. 支持报表配置自定义类和方法嵌码，并上传对应的嵌码状态
2. 新增用户信息获取方式，所有获取方式支持getter chain
    * 方法参数
    * 方法返回值
    * 当前对象
    * Http Response Header
    * Web request path
3. 支持多个用户信息获取方式同时生效，并根据获取方式的优先级确认最终用户信息
4. 新增数据项数据获取方式，所有获取方式支持getter chain
    * Web request query string
    * Http request header
    * Http Post parameter
    * Http response header
    * Servlet session attribute
    * Web request URL
    * Web request path
5. 支持Feign插件，支持版本**9.5.0**到**10.2.3**
6. 支持Spring cloud openfeign插件，支持版本**2.0.0.RELEASE**到**2.1.1.RELEASE**

###### 改进

1. 优化探针连接方式，减少网络策略的开通

###### 修复

1. 修复ContextType获取失败时导致browser探针无法获取TINGYUN_DATA的问题

#### 2019-04-17    *Version:3.1.2*

###### 修复

1. 修复在资源保护情况下概率性出现类初始化失败的问题

#### 2019-04-12    *Version:3.1.1*

###### 修复

1. 修复在Servlet3.0异步情况下，应用概率性丢失请求参数的问题

#### 2019-03-27    *Version:3.1.0*

###### 新增

1. 支持CXF 3.1
2. 支持Glassfish Jersey 2.9
3. 支持Sun Jersey 1.19

###### 改进

1. 优化通信协议，大幅提高TPS，降低CPU使用率
2. 优化数据项功能，支持接口调用
3. 优化自定义嵌码功能，支持自动擦除无用的嵌码

###### 修复

1. 修复资源保护下采样率不准的问题
2. 修复探针部分性能指标丢失的问题
3. 修复Dubbo结合Spring动态代理使用后，事务命名不正确的问题
4. 修复采集Spring Boot的jar包时空指针的问题

#### 2019-02-18    *Version:3.0.1*

###### 新增

1. 对用户溯源采集的用户标识增加数据处理支持

###### 改进

1. 支持在接口中使用Spring注解的事务命名
2. 增强Browser嵌码的兼容性

###### 修复

1. 修复获取不到Glassfish版本号的问题
2. 修复异步请求下时间统计不正确的问题
3. 修复获取Resin端口不正确的问题
4. 修复Weblogic EJB调用的事务无法采集的问题
5. 修复获取不到Wildfly8版本号的问题
